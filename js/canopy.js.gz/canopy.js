// Above the Canopy v4 - animation engine (plain canvas 2D, no dependencies).
// World units: the scene is H = 600 units tall; the canvas is scaled to fit.
// Exported as an ES module and driven from Blazor (Pages/Home.razor) via JS interop.
//
// Story: an eagle Leader above the canopy holds the vision (the pyramid), an owl Manager
// under the canopy scouts obstacles and communicates, and four koalas (the Team) do the
// work on the forest floor: hacking through bushes and solving eight obstacles.

const H = 600;
const WORLD_W = 6000;
const GROUND = 480;          // forest floor (normal level)
const LOW_GROUND = 565;      // forest floor between the cliff (down) and the rock wall (up)
const CANOPY_TOP = 120;
const CANOPY_BOTTOM = 245;
const LEADER_Y = 68;
const MANAGER_Y = 320;
const START_X = 120;
const GOAL_X = 5560;         // pyramid centre
const PYR_HALF = 230;
const PYR_APEX = 52;
const MEMBER_GAP = 36;
const KOALA_SCALE = 1.45;
const WALK_SPEED_INFORMED = 46;
const WALK_SPEED_UNINFORMED = 42;
// v4: project time. 1 project day = 2 seconds of animation at 1x speed (a comms-ON run is roughly 100 days).
const SEC_PER_DAY = 2;
const dd = n => n + (n === 1 ? " day" : " days");
const dayOf = t => Math.floor(t / SEC_PER_DAY) + 1;
const TEAM_COLORS = ['#f28c28', '#3f8fe8', '#f2c233', '#9b59d0']; // hard hats / bandanas
// v5: the koalas have names (shown on hover and in the team info card). Wattle is the smallest.
const KOALAS = [
  { name: 'Kip', desc: 'orange hard hat' },
  { name: 'Banjo', desc: 'blue bandana' },
  { name: 'Matilda', desc: 'yellow hard hat' },
  { name: 'Wattle', desc: 'purple bandana, the smallest' },
];
const KOALA_SIZE = [1, 1, 1, 0.86];
const COACH_X = 1000;                         // the thick bush where Wattle struggles (and gets coached)
const LANTANA = { x0: 3190, x1: 3470, n: 8 }; // thick lantana scrub on the planned route
const CREEK = { x0: 3150, x1: 3525 };         // the dry creek bed alongside it (Banjo's shortcut)
const LANTANA_HACK = { on: 2.2, off: 2.8 };
const BREAK_X = 4900;                         // top of the rock wall: time for a break

// Obstacle layout, in path order. Distinct problems, distinct solutions.
const OB_DEFS = [
  { type: 'vines',   x: 640,  w: 110, name: 'tangle of vines',  icon: '🌿' },
  { type: 'boulder', x: 1150, w: 120, name: 'giant boulder',    icon: '🪨' },
  { type: 'river',   x: 1760, w: 190, name: 'fast river',       icon: '🌊' },
  { type: 'bog',     x: 2340, w: 210, name: 'smelly bog',       icon: '🟫' },
  { type: 'log',     x: 2950, w: 170, name: 'fallen giant log', icon: '🪵' },
  { type: 'cliff',   x: 3560, w: 60,  name: 'cliff edge',       icon: '⛰️' },
  { type: 'bees',    x: 4150, w: 120, name: 'bees\' nest',      icon: '🐝' },
  { type: 'wall',    x: 4760, w: 44,  name: 'rock wall',        icon: '🧗' },
];
const defOf = type => OB_DEFS.find(o => o.type === type);

// v3: unexpected events the Manager could NOT see coming. The koalas discover them and report UP the chain.
const SURPRISE_DEFS = [
  { type: 'sinkhole', x: 2150, w: 90, name: 'sinkhole', icon: '🕳️',
    reveal: 'SURPRISE! The ground collapses into a sinkhole right in front of the koalas. Nobody saw it coming, not even the Manager.',
    revSay: 'Whoa! The ground just vanished! 😱',
    up: 'Manager! A sinkhole just opened up! 🕳️', ack: 'Stay back! I\'ll tell the boss.',
    toLeader: 'Unplanned sinkhole. Team needs planks, about a week.', leaderReply: 'Safety first, take the week. Goal stays the same. 🔺',
    down: 'Boss says take the time. Gather planks!', teamAck: 'Thanks! On it 👍',
    gatherCap: 'Gathering materials: the koalas fan out into the bush and carry planks back to the sinkhole.',
    fixCap: 'Backed by the Manager and the Leader, the koalas lay planks across the sinkhole and cross safely.',
    aloneCap: 'Alone and unsure if they\'re allowed the time, the koalas slowly rig a crossing.' },
  { type: 'treefall', x: 3900, w: 150, name: 'fallen gum tree', icon: '🌳',
    reveal: 'SURPRISE! CRAAACK! A huge gum tree crashes down across the track. Even the Manager didn\'t see that one coming.',
    revSay: 'TIMBERRR! 😵',
    up: 'Manager! A gum tree just fell across the track! 🌳', ack: 'Is everyone okay? Escalating now.',
    toLeader: 'Tree down on the track. Team needs saws and safety gear, about 5 or 6 days.', leaderReply: 'Yes! Sending saws and safety gear down now. 🪂',
    down: 'The gear is down. Saw it up and roll it aside, carefully!', teamAck: 'Thanks, boss! Saws out! 🪚', support: true,
    fixCap: 'With the delay approved and the new saws, the koalas cut up the trunk and roll the pieces off the track.',
    aloneCap: 'Nobody answers, so the koalas hack at the trunk for ages.' },
  { type: 'snake', x: 4650, w: 110, name: 'brown snake', icon: '🐍',
    reveal: 'SURPRISE! A big brown snake slides out onto the track. Nobody could have planned for this.',
    revSay: 'S-s-snake!! 🐍',
    up: 'Manager! Big brown snake on the track! 🐍', ack: 'Freeze! Don\'t touch it. Telling the boss.',
    toLeader: 'Snake on the track. Team needs to wait it out, a few days.', leaderReply: 'No rush. Let it pass safely. Goal stays the same. 🔺',
    down: 'Boss says wait it out. Safety first!', teamAck: 'Waiting quietly... 🤫',
    fixCap: 'The koalas wait calmly at a safe distance until the snake slithers off into the bush.',
    aloneCap: 'Nobody tells them what to do, so the koalas panic, back off and wait nervously.' },
];

// v3: meetings above the canopy. Visiting eagles bring competing priorities; the Leader filters them.
const MEETINGS = [
  { atX: 1300, who: 'Finance, Marketing and Safety',
    visitors: [
      { label: 'FINANCE', body: '#3d6b45', head: '#d9f2c4', size: 0.82, ask: 'Budget cuts? 💸' },
      { label: 'MARKETING', body: '#9c3f6b', head: '#ffd6e8', size: 0.74, ask: 'Urgent: rebrand! 🎨' },
      { label: 'SAFETY', body: '#a8641e', head: '#ffe2b8', size: 0.92, ask: 'Safety gear for koalas', accept: true },
    ],
    yes: 'Yes to safety gear: it gets us to the pyramid. ✅', no: 'Rebrand and budget review: not now. The pyramid comes first.' },
  { atX: 2560, who: 'the Board, Another Project and Product',
    visitors: [
      { label: 'BOARD', body: '#37474f', head: '#eceff1', size: 1.0, ask: 'Can you also run the picnic?' },
      { label: 'OTHER PROJECT', body: '#5d4037', head: '#d7ccc8', size: 0.76, ask: 'Lend us two koalas?' },
      { label: 'PRODUCT', body: '#1565c0', head: '#cfe3ff', size: 0.86, ask: 'Better map to the pyramid', accept: true },
    ],
    yes: 'A better map? Yes, that helps us get there. ✅', no: 'The koalas need that time: the picnic can wait! 🛡️',
    support: 'The Leader backs the team: no picnic and no lending koalas. Protecting the team\'s time protects the goal.' },
  { atX: 5030, who: 'Strategy, HR and Customers',
    visitors: [
      { label: 'STRATEGY', body: '#6a1b9a', head: '#ead6ff', size: 0.9, ask: 'New initiative! 🚀' },
      { label: 'HR', body: '#00796b', head: '#c8f2ea', size: 0.78, ask: 'Can you also do a survey?' },
      { label: 'CUSTOMERS', body: '#c62828', head: '#ffd9d9', size: 0.84, ask: 'Pyramid opening: still on?', accept: true },
    ],
    yes: 'Yes, the pyramid opening is on. That IS the goal. ✅', no: 'New initiative and survey: after we arrive. Not now.' },
];
const MEETING_PHASES = { arrive: 2.0, ask: 3.0, decide: 3.0, leave: 1.8 };

// v4: manager-level meetings under the canopy. Another owl flies in to coordinate with the Manager while the
// koalas are busy gathering materials, then flies off and the Manager refocuses on the team.
const MGR_MEETINGS = [
  { ob: 'river', label: 'OPS MANAGER', body: '#2e7d6f', wing: '#1f5a50', belly: '#d3f0e8', who: 'An Ops manager', topic: 'to share resources',
    lines: [['visitor', 'Your team needs logs? We have spare! 🪵'], ['manager', 'Yes please! Drop them by the river.'], ['visitor', 'Done. Shout if you need more.'], ['manager', 'Legend, thanks! 🤝']] },
  { ob: 'bog', label: 'PMO', body: '#5c6b7a', wing: '#3e4a56', belly: '#e3e9ef', who: 'The PMO', topic: 'for a quick status sync',
    lines: [['visitor', 'Status sync? 📋'], ['manager', 'River done, bog in progress. On track.'], ['visitor', 'Great, I\'ll update the roadmap.'], ['manager', 'Thanks! Back to my koalas.']] },
  { ob: 'cliff', label: 'PROJECT MANAGER B', body: '#b8621b', wing: '#8a4510', belly: '#ffe3c4', who: 'Project manager B', topic: 'to coordinate between teams',
    lines: [['visitor', 'Can we share your rope after? 🪢'], ['manager', 'Sure, once my koalas are down the cliff.'], ['visitor', 'Thanks! Need a ladder later? 🪜'], ['manager', 'Yes please! Leave it by the wall.']] },
];
const MM_PHASES = { arrive: 1.5, talk: 6.8, leave: 1.5 };
const MM_LINE_GAP = 1.7;

// Workplace distractions for the Leader and Manager, triggered by how far the team has got.
const DISTRACTIONS = [
  { who: 'leader', kind: 'magpie', atX: 770,
    say: 'Argh! Swooping magpies! 🐦', say2: 'Not the eyes, not the eyes!',
    cap: 'Distraction! A magpie swoops the Leader. (Every Aussie knows that feeling.)',
    refocus: 'Shake it off. Eyes on the pyramid. 🔺' },
  { who: 'manager', kind: 'meeting', atX: 380,
    say: '📅 Meeting request: "Sync about the sync"', say2: 'Ugh, another meeting...',
    cap: 'Distraction! Mid-flight, the Manager gets yet another meeting request.',
    refocus: 'Declined. Back to the team. ✅' },
  { who: 'leader', kind: 'email', atX: 3700,
    say: '📧 URGENT!!! Reply-all chain (47 new)', say2: 'Is it actually urgent though?',
    cap: 'Distraction! An "urgent" email storm floods the Leader\'s inbox.',
    refocus: 'That can wait. Back to the vision. 🔺' },
  { who: 'manager', kind: 'mosquito', atX: 3330,
    say: 'Bzzz! Mozzies everywhere! 🦟', say2: 'Shoo! SHOO!',
    cap: 'Distraction! A cloud of mozzies swarms the Manager.',
    refocus: 'Swatted. Back to scouting. 🔍' },
  { who: 'leader', kind: 'storm', atX: 4480,
    say: 'Whoa! What a wind gust! 🌬️', say2: 'Hold on... hold on...',
    cap: 'Distraction! A storm front blows in and a gust knocks the Leader off course.',
    refocus: 'Steady. Back on course for the pyramid. 🔺' },
  { who: 'manager', kind: 'branch', atX: 3000,
    say: 'Oof! Snagged in the branches! 🌿', say2: 'Who put this vine here?!',
    cap: 'Distraction! The Manager flies into a snag of branches and vines.',
    refocus: 'Untangled. Back to guiding the team. ✅' },
];

const LEADER_TALK = [
  ['Keep heading for the pyramid! 🔺', 'On it, still bearing east. 👍'],
  ['How are the koalas going?', 'Steady progress, boss. Hacking through!'],
  ['Remember why we\'re doing this!', 'I\'ll remind the team. 📣'],
  ['Any blockers I can help with?', 'All handled for now, thanks!'],
  ['We\'re over halfway. Stay focused!', 'Copy that. 🧭'],
];
const MANAGER_CHECKIN = [
  ['How\'s everyone going down there?', 'Hacking away! 🌿'],
  ['Water break at the next clearing!', 'Yes please! 💧'],
  ['Great pace, team. Keep it up!', 'Cheers! 😊'],
  ['Watch your footing, it\'s slippery.', 'Thanks for the heads-up!'],
  ['Path bends right past the big gum tree.', 'Got it, right at the gum! 🌳'],
];
const LONELY = ['Is anyone up there? 😕', 'Are we even going the right way?', 'Which way now? 🤔', 'Nobody tells us anything...'];
const RECOGNITION = ['Great work, koalas! 🦅', 'Brilliant teamwork!', 'That\'s how it\'s done!', 'So proud of this team!'];
const CHEERS = ['Woohoo! 🎉', 'Teamwork! 🤝', 'Nailed it! 😎', 'Easy as! 🐨', 'Too easy!'];
const BUSH_LINES = [
  'Between the big obstacles, the koalas hack through bush after bush: the everyday work nobody up top sees.',
  'Hack, step, hack... most of a team\'s day is this steady, constant work.',
  'Little bushes, again and again. Small daily problems the team just quietly solves.',
  'The everyday grind: no drama, just effort. It\'s what moves the team forward.',
];

let canvas, ctx, dotnet, raf = 0, lastT = 0, ro = null;
let fog, fctx;
let scale = 1, viewW = 1200, camX = 0, camTarget = 0;
let deco = null;
let S = null;
const settings = { speed: 1, playing: true, view: 'all', comms: true };

// ---------- helpers ----------
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const ease = t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
const pick = (arr, i) => arr[((i % arr.length) + arr.length) % arr.length];
function rng(seed) { let s = seed; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
function call(method, ...args) { try { dotnet && dotnet.invokeMethodAsync(method, ...args); } catch (e) { /* ignore */ } }
function inZone(x, pad, types) {
  return OB_DEFS.concat(SURPRISE_DEFS).some(o => (!types || types.includes(o.type)) && x > o.x - pad && x < o.x + o.w + pad);
}

// ---------- world ----------
function makeObstacles() {
  return OB_DEFS.map(o => Object.assign({}, o, { prog: 0, spotted: false, informed: false, done: false, active: false, angry: 0, route: false }));
}
const ob = type => S.obstacles.find(o => o.type === type);

function buildDeco() {
  const r = rng(42);
  const d = { trunks: [], blobs: [], hang: [], bushes: [], far: [], clouds: [], tufts: [], shafts: [] };
  for (let x = 20; x < WORLD_W; x += 70 + r() * 70) {
    if (Math.abs(x - GOAL_X) < PYR_HALF + 30) continue;
    if (inZone(x, 20, ['river', 'bog', 'cliff', 'wall', 'log'])) continue;
    d.trunks.push({ x, w: 16 + r() * 20, shade: r() });
  }
  for (let x = -60; x < WORLD_W + 60; x += 22 + r() * 18) {
    d.blobs.push({ x, y: CANOPY_TOP + 18 + r() * (CANOPY_BOTTOM - CANOPY_TOP - 30), rad: 34 + r() * 30, c: Math.floor(r() * 4) });
  }
  for (let x = 0; x < WORLD_W; x += 40 + r() * 60) d.hang.push({ x, len: 50 + r() * 120, ph: r() * 6 });
  for (let x = 0; x < WORLD_W; x += 45 + r() * 55) {
    if (inZone(x, 10, ['river', 'bog', 'log', 'wall', 'boulder'])) continue;
    if (Math.abs(x - GOAL_X) < PYR_HALF) continue;
    if (x > BREAK_X - 10 && x < BREAK_X + 140) continue; // the break clearing
    d.bushes.push({ x, s: 0.7 + r() * 0.6, c: Math.floor(r() * 3) });
  }
  for (let x = 0; x < WORLD_W * 0.5 + 1500; x += 40 + r() * 50) d.far.push({ x, h: 140 + r() * 160, w: 30 + r() * 30 });
  for (let i = 0; i < 12; i++) d.clouds.push({ x: r() * 2400, y: 20 + r() * 60, s: 0.6 + r() * 0.8 });
  for (let x = 0; x < WORLD_W; x += 9 + r() * 14) d.tufts.push({ x, h: 4 + r() * 8 });
  for (let x = 100; x < WORLD_W; x += 260 + r() * 260) d.shafts.push({ x, w: 30 + r() * 40 });
  return d;
}

// Small bushes right on the path: the team's constant everyday work.
function makePathBushes() {
  const r = rng(99), list = [];
  for (let x = 360; x < GOAL_X - PYR_HALF - 90; x += 115 + r() * 80) {
    if (inZone(x, 110)) continue;
    if ((x > LANTANA.x0 - 70 && x < LANTANA.x1 + 60) || Math.abs(x - COACH_X) < 90 || (x > BREAK_X - 20 && x < BREAK_X + 150)) continue;
    list.push({ x, hp: 1, cut: false, s: 0.85 + r() * 0.3 });
  }
  list.push({ x: COACH_X, hp: 1, cut: false, s: 1.15, coach: true });
  for (let k = 0; k < LANTANA.n; k++) list.push({ x: LANTANA.x0 + k * (LANTANA.x1 - LANTANA.x0) / (LANTANA.n - 1), hp: 1, cut: false, s: 1.1 + (k % 3) * 0.08, lantana: true });
  return list.sort((a, b) => a.x - b.x);
}

function groundBase(x) {
  const c = defOf('cliff'), w = defOf('wall');
  if (x < c.x) return GROUND;
  if (x <= c.x + c.w) return lerp(GROUND, LOW_GROUND, (x - c.x) / c.w);
  if (x < w.x) return LOW_GROUND;
  if (x <= w.x + w.w) return lerp(LOW_GROUND, GROUND, (x - w.x) / w.w);
  return GROUND;
}
function memberY(x) {
  const r = ob('river');
  if (x > r.x && x < r.x + r.w) return r.prog >= 1 ? GROUND - 6 : GROUND + 30;
  const b = ob('bog');
  if (x > b.x && x < b.x + b.w) {
    if (b.prog < 1) return GROUND + 24; // sinking
    const seg = b.w / 6;
    return GROUND - 2 - Math.abs(Math.sin(Math.PI * (x - b.x) / seg)) * 14; // hop stone to stone
  }
  return groundBase(x);
}
function laneOffset(x) {
  // When the team goes around the boulder they swing into the foreground lane.
  let off = 0;
  const b = ob('boulder');
  if (b.route) { const a = b.x - 70, z = b.x + b.w + 70; if (x > a && x < z) off += Math.sin(Math.PI * (x - a) / (z - a)) * 34; }
  // v5: Banjo's creek route runs in the foreground lane, beside the lantana
  if (S.idea && S.idea.go && x > CREEK.x0 && x < CREEK.x1) off += Math.pow(Math.sin(Math.PI * (x - CREEK.x0) / (CREEK.x1 - CREEK.x0)), 0.5) * 30 * Math.min(1, S.idea.goT / 1.2);
  return off;
}

// ---------- state ----------
function reset() {
  S = {
    t: 0,
    obstacles: makeObstacles(),
    pathBushes: makePathBushes(),
    distractions: DISTRACTIONS.map(d => Object.assign({ done: false }, d)),
    surprises: SURPRISE_DEFS.map(d => Object.assign({}, d, { isSurprise: true, rev: 0, prog: 0, done: false, active: false, chainDone: false })),
    meetings: MEETINGS.map(m => Object.assign({ done: false }, m)),
    mgrMeetings: MGR_MEETINGS.map(m => Object.assign({ done: false, pending: false }, m)), day: 1,
    waiters: [],
    team: { x: START_X + 70, mode: 'idle', seq: null, step: 0, stepT: 0, stepStartX: 0, mood: '', m0: 0, m0y: 0,
      wrong: 0, surprises: 0, distractions: 0, priorities: 0, reported: 0, syncs: 0, upT: 0, seqStart: 0, cheer: 0, bush: null, hackT: 0, bushesCut: 0, cleared: 0,
      ideas: 0, breaks: 0, tired: false, fresh: 0, supplied: 0, lead: -1, leaf: -1, coached: false, onDone: null },
    mgr: { x: START_X + 140, y: MANAGER_Y, dy: 0, alert: 0, ready: false, ox: 0, oy: 0, rot: 0, dist: null, focusT: 0, meeting: null, task: null, busy: false },
    leader: { x: START_X + 260, y: LEADER_Y, beam: null, beamT: 0, ox: 0, oy: 0, rot: 0, dist: null, meeting: null },
    bubbles: [], queue: { leader: [], manager: [], team: [], visitor: [] }, pulses: [], events: [], particles: [],
    caption: '', phase: '', capT: 0, cap: null, capQ: [], pend: [], finished: false, introCam: 'start', selected: null, hover: -1,
    idea: { started: false, adopted: false, go: false, goT: 0, saved: 0, bulb: false }, drop: null, leafFly: null, kb: [], kpos: [],
    coachDone: false, breakDone: false,
    nextLeaderTalk: 26, leaderTalkI: 0, nextCheckin: 34, checkinI: 0,
  };
  camX = camTarget = 0;
  call('OnRestarted');
  call('OnDay', 1);
  scheduleIntro();
}

function stats() { const t = S.team; call('OnStats', t.wrong, t.surprises, t.distractions, t.priorities, t.reported, t.syncs, t.ideas); }
function later(delay, fn) { S.events.push({ at: S.t + delay, fn }); }
function whenFree(cond, fn) { S.pend.push({ cond, fn }); }
const mgFree = () => { const m = S.mgr; return m.ready && !m.dist && !m.meeting && !m.task && !m.busy; };
// v5: captions queue instead of cutting each other off. Every caption stays up for at least CAP_MIN seconds;
// a caption can also hold the bar (for seconds, or while a predicate is true), e.g. for the length of a meeting.
// Queued captions are dropped once they're stale (or no longer match what's on screen), so the bar never lags behind.
const CAP_MIN = 1.8, CAP_STALE = 6;
// Priorities: 0 = routine (spotted / refocus / cleared), 1 = normal, 2 = key moments (surprises, meetings, v5 moments).
// A key moment can cut short a routine caption; routine captions go stale quickly.
const LOW_PHASES = ['Communication', 'Refocus', 'Execution', 'Everyday work', 'Focus'];
function caption(text, phase, opts = {}) {
  const ph = phase || S.phase;
  const it = { text, phase: ph, hold: opts.hold, valid: opts.valid, at: S.t, prio: opts.prio != null ? opts.prio : LOW_PHASES.includes(ph) ? 0 : (ph === ph.toUpperCase() || opts.hold ? 2 : 1) };
  if (opts.force) S.capQ = [];
  else if (capHeld(it.prio)) { S.capQ.push(it); if (S.capQ.length > 5) S.capQ.shift(); return; }
  showCaption(it);
}
function capHeld(prio = 1) {
  const c = S.cap; if (!c) return false;
  if (prio >= 2 && c.prio === 0 && S.t - c.shown > 0.8) return false;
  if (S.t - c.shown < CAP_MIN) return true;
  if (typeof c.hold === 'function') return !!c.hold();
  if (typeof c.hold === 'number') return S.t - c.shown < c.hold;
  return false;
}
function showCaption(it) {
  it.shown = S.t; S.cap = it; S.caption = it.text; S.capT = S.t; S.phase = it.phase;
  call('OnCaption', it.text, it.phase);
}
function pumpCaptions() {
  if (!S.capQ.length) return;
  S.capQ = S.capQ.filter(c => S.t - c.at < (c.prio === 0 ? 3 : CAP_STALE) && (!c.valid || c.valid()));
  if (!S.capQ.length) return;
  const best = S.capQ.reduce((a, c) => c.prio > a.prio ? c : a, S.capQ[0]);
  if (capHeld(best.prio)) return;
  S.capQ.splice(S.capQ.indexOf(best), 1); showCaption(best);
}
// A badge shown under one koala's feet (name + what they did), so it never collides with the speech bubbles.
function kbadge(i, text, dur, col = '#ffd34d') { S.kb = S.kb.filter(b => b.i !== i); S.kb.push({ i, text, t: dur, dur, col }); }
// Speech bubbles: one per speaker on screen at a time; extra lines queue up so nothing overlaps or gets lost.
const MIN_SHOW = 1.6;
function bubble(who, text, dur = 3.2, priority = false) {
  if (priority) { S.queue[who] = []; showBubble(who, text, dur); return; }
  const cur = S.bubbles.find(b => b.who === who);
  if (cur && cur.t < MIN_SHOW) {
    const q = S.queue[who];
    if (q.length >= 3) q.shift();
    q.push({ text, dur });
    return;
  }
  showBubble(who, text, dur);
}
function showBubble(who, text, dur) {
  S.bubbles = S.bubbles.filter(b => b.who !== who);
  S.bubbles.push({ who, text, t: 0, dur });
}
function pulse(from, to, color, onArrive, dur = 1.3) { S.pulses.push({ from, to, color, onArrive, t: 0, dur }); }
const PULSE_COL = { leader: '#ffd34d', manager: '#c792ff', team: '#5dd3ff' };
// A message that travels: speaker says it, a pulse carries it, the listener replies.
function say(from, to, text, reply, onArrive) {
  bubble(from, text, 3);
  pulse(from, to, PULSE_COL[from], () => { if (reply) bubble(to, reply, 2.8); onArrive && onArrive(); });
}

function agentPos(who) {
  if (who === 'leader') return { x: S.leader.x + S.leader.ox, y: S.leader.y + S.leader.oy };
  if (who === 'manager') return { x: S.mgr.x + S.mgr.ox, y: S.mgr.y + S.mgr.oy };
  if (who === 'visitor') return S.mgr.meeting ? mgrVisitorPos() : { x: -9999, y: 0 };
  const tx = S.team.x;
  const lo = laneOffset(tx);
  return { x: tx - MEMBER_GAP * 1.5, y: memberY(tx) - 62 * (1 + lo / 120) + lo };
}

function scheduleIntro() {
  caption('High above the canopy, the Leader can see where the team starts... ', 'Vision');
  S.leader.beam = 'start'; S.leader.beamT = 2.6;
  later(2.6, () => {
    S.introCam = 'goal';
    S.leader.beam = 'goal'; S.leader.beamT = 3.2;
    caption('...and the end goal: a pyramid poking out of the top of the canopy, far to the east.', 'Vision');
    bubble('leader', 'There it is: the pyramid! 🔺', 3);
  });
  later(5.8, () => {
    S.introCam = null;
    caption('The Leader shares the vision and the direction with the Manager below the canopy.', 'Direction');
    say('leader', 'manager', 'Head east to the pyramid.', 'Got it. I\'ll scout a route.', () => {
      caption('The Manager turns the vision into a plan, flying ahead under the canopy to scout the way.', 'Planning');
      S.mgr.ready = true;
      later(1.4, kickOffTeam);
    });
  });
}

function kickOffTeam() {
  if (settings.comms) {
    say('manager', 'team', 'Koalas: east to the pyramid! I\'ll warn you about hazards.', 'East it is! Tools out! 🐨💪', () => {
      S.team.mode = 'walk';
      caption('The koalas set off on the forest floor. Down here they can only see a few metres ahead.', 'Execution');
    });
  } else {
    caption('Communication is OFF: the koalas never hear the plan, so they don\'t even know which way to go.', 'Execution');
    runSeq([
      { dur: 2.2, cap: 'Which way? The koalas argue and wander west first...', mood: 'confused', move: -60, wrong: true, say: 'Which way?? 🤔' },
      { dur: 2.0, mood: 'confused', move: 60, say: 'Hmm, maybe this way...' },
    ], null);
  }
}

// ---------- obstacle sequences ----------
// Each obstacle has an "informed" script (the manager warned them) and an "uninformed" one (comms OFF).
// Step fields: dur, cap (caption), say (team bubble), mood, move (dx over the step), prog (advance the
// obstacle's build/clear progress), m0/m0y (front koala offsets), ask ([team request, manager reply]),
// wrong / surprise (counters), onStart.
function sequenceFor(o, informed) {
  switch (o.type) {
    case 'vines': return informed ? [
      { dur: 0.6, mood: 'work', cap: 'Warned about the vines, the koalas arrive with their cutting tools ready and clear a path straight through.', say: 'Tools out! ✂️' },
      { dur: 2.6, mood: 'work', prog: true },
    ] : [
      { dur: 1.6, mood: 'stuck', cap: 'Nobody warned them: the koalas walk into a tangle of vines and get stuck!', say: 'We\'re stuck! 😩', surprise: true },
      { dur: 1.8, mood: 'confused', move: -70, wrong: true, cap: 'Someone runs back to camp for better tools...' },
      { dur: 1.6, mood: 'walk', move: 70 },
      { dur: 3.4, mood: 'work', prog: true, cap: 'Finally, they start hacking through the vines.' },
    ];
    case 'boulder': return informed ? [
      { dur: 0.6, mood: '', cap: 'Warned early, the koalas know the boulder is too big to go around, and the Manager has arranged training.', say: 'Training time! 🎓' },
      { dur: 3.0, train: true, cap: 'Investing in team skills: a quick training session. The koalas learn to use hammers and chisels.', say: 'Training: hammer and chisel! 🔨' },
      { dur: 5.4, mood: 'chisel', form: 'rock', prog: true, cap: 'Upskilled! Together the koalas break the boulder down: tap, tap, tap... cracks appear, then it splits.', say: 'Tap... tap... TAP! 🔨', onStart: () => { S.team.upT = 3.6; } },
      { dur: 1.8, mood: 'walk', move: o.w + 40, cap: 'The rubble is swept aside off the path. The new skills stay with the team for the rest of the journey.' },
    ] : [
      { dur: 1.2, mood: 'stuck', cap: 'BONK! The koalas walk straight into a giant boulder.', say: 'Ouch! A boulder?! 💥', surprise: true },
      { dur: 2.2, mood: 'work', cap: 'They try to push it out of the way. It doesn\'t budge.', say: 'Push! PUSH!' },
      { dur: 2.0, mood: 'confused', move: -90, wrong: true, cap: 'Wrong turn: they back-track looking for a way around. There isn\'t one.', say: 'Which way now? 🤷' },
      { dur: 1.6, mood: 'walk', move: 90 },
      { dur: 4.4, train: true, slow: true, cap: 'Nobody arranged any training, so the koalas teach themselves hammer and chisel by trial and error.', say: 'How does this hammer work?? 🤔' },
      { dur: 7.2, mood: 'chisel', form: 'rock', prog: true, cap: 'Self-taught at last, they chip away at the boulder. It takes much longer.', say: 'Tap... ow... tap...', onStart: () => { S.team.upT = 3.6; } },
      { dur: 1.8, mood: 'walk', move: o.w + 40, cap: 'Finally, rubble. Skills built the hard way.' },
    ];
    case 'river': return informed ? [
      { dur: 0.6, mood: 'work', cap: 'The Manager spotted the river early, so the koalas know exactly what they need: logs for a bridge.' },
      { dur: 2.8, mood: '', phase: 'DELEGATION', cap: 'Delegation: the Manager hands Kip the lead on the bridge build. Growing people means trusting them with real responsibility.',
        onStart: () => { S.team.lead = 0; kbadge(0, '⭐ Kip leads the build', 9); say('manager', 'team', 'Kip, you lead the bridge build! ⭐', 'Kip: On it! Follow me, team! 🌟'); } },
      { dur: 4.2, gather: 'logs', cap: 'Gathering materials: Kip sends the koalas into the bush to pick up logs and carry them back to the bank.', say: 'Kip: Spread out, grab logs! 🪵' },
      { dur: 3.4, mood: 'work', prog: true, cap: 'Logs gathered, Kip directs the build and the bridge goes up.' },
    ] : [
      { dur: 1.0, mood: 'confused', cap: 'A river! Nobody saw it coming.', say: 'A river?! 😮', surprise: true },
      { dur: 1.8, mood: 'stuck', m0: p => Math.sin(Math.PI * p) * 60, cap: 'SPLASH! One brave koala tries to wade across. Far too deep!', say: 'Too deep! 💦' },
      { dur: 5.8, gather: 'logs', lost: true, wrong: true, cap: 'Nobody told them what to bring, so the koalas scatter into the bush hunting for anything that floats...', say: 'Logs? Sticks? Anything?! 🤷' },
      { dur: 4.2, mood: 'work', prog: true, cap: '...and slowly build a bridge by trial and error.' },
    ];
    case 'bog': return informed ? [
      { dur: 0.6, mood: 'work', cap: 'The Manager mapped the firm spots in the bog, so the koalas know they need flat stepping stones.', say: 'Find flat stones! 🪨' },
      { dur: 4.0, gather: 'stones', cap: 'Gathering materials: the koalas head off the path, pick up flat stones and carry them back.' },
      { dur: 2.8, mood: 'work', prog: true, cap: 'Stone by stone, they lay stepping stones and hop across.' },
    ] : [
      { dur: 1.0, mood: 'confused', cap: 'Squelch! A smelly bog nobody mentioned.', say: 'Ew, a bog?! 🤢', surprise: true },
      { dur: 2.0, mood: 'stuck', m0: p => Math.sin(Math.PI * p) * 50, cap: 'One koala steps in and sinks up to its tummy!', say: 'Help, I\'m sinking! 😱' },
      { dur: 5.6, gather: 'stones', lost: true, wrong: true, cap: 'They wander off the path to hunt for rocks, not sure what size they need...', say: 'Which rocks?? 🤔' },
      { dur: 3.8, mood: 'work', prog: true, cap: '...and test every wobbly stepping stone one at a time.' },
    ];
    case 'log': return informed ? [
      { dur: 0.6, mood: 'work', cap: 'Warned about the fallen giant log, the koalas head straight for its hollow and crawl through.', say: 'Through the hollow! 🪵' },
      { dur: 1.8, mood: 'work', prog: true, cap: 'A quick sweep of the cobwebs and they\'re in.' },
    ] : [
      { dur: 1.2, mood: 'stuck', cap: 'A giant fallen log blocks the path!', say: 'It\'s HUGE! 😧', surprise: true },
      { dur: 2.2, mood: 'work', m0y: p => -Math.sin(Math.PI * p) * 46, cap: 'They try to climb over it... and slide right back down.', say: 'Too slippery! 😵' },
      { dur: 2.4, mood: 'confused', move: -100, wrong: true, cap: 'Wrong turn: they trek back along the log looking for an end.', say: 'Is there a way through?' },
      { dur: 1.8, mood: 'walk', move: 100 },
      { dur: 2.6, mood: 'work', prog: true, cap: 'Finally someone spots the hollow and they clear out the cobwebs.' },
    ];
    case 'cliff': return informed ? [
      { dur: 0.6, mood: 'work', cap: 'The Manager found the safe spot to climb down. The koalas need rope, so they collect long vines to braid one.', say: 'Grab long vines! 🌿' },
      { dur: 3.8, gather: 'vines', cap: 'Gathering materials: the koalas fan out and drag long vines back to braid into a rope.' },
      { dur: 2.4, mood: 'work', prog: true, cap: 'Rope braided and tied off at the marked spot, they abseil down the cliff.' },
    ] : [
      { dur: 1.2, mood: 'stuck', cap: 'Dead end! The ground just drops away at a cliff.', say: 'Whoa! A cliff! 😱', surprise: true },
      { dur: 2.4, mood: 'confused', move: -80, wrong: true, cap: 'Wrong turn: they wander along the edge looking for a way down...', say: 'Maybe further back?' },
      { dur: 1.8, mood: 'confused', move: 80, say: 'Nope... back again.' },
      { dur: 4.4, gather: 'vines', lost: true, cap: 'No rope, so they hunt around for anything long and strong...', say: 'Will vines work?? 🤔' },
      { dur: 3.0, mood: 'work', prog: true, cap: 'Eventually they rig a rope and lower themselves down.' },
    ];
    case 'bees': return informed ? [
      { dur: 0.6, mood: 'sneak', cap: 'The Manager spotted a bees\' nest. The koalas tiptoe underneath in total silence.', say: 'Shhh... tiptoe! 🤫' },
      { dur: 4.0, mood: 'sneak', move: o.w + 90 },
    ] : [
      { dur: 1.0, mood: 'walk', move: 40, cap: 'Chatting loudly, the koalas stomp right under a bees\' nest...', say: 'La la la! 🎵' },
      { dur: 2.0, mood: 'stuck', move: -130, wrong: true, surprise: true, cap: 'BZZZ! The bees attack and the koalas flee back the way they came!', say: 'BEES!! RUN! 🐝', onStart: () => { o.angry = 4; } },
      { dur: 2.0, mood: 'confused', cap: 'They wait for the swarm to calm down...', say: 'Ouch... ouch... ouch.' },
      { dur: 1.6, mood: 'walk', move: 90 },
      { dur: 4.0, mood: 'sneak', move: o.w + 90, cap: 'Lesson learned the hard way: they sneak past quietly.' },
    ];
    case 'wall': return informed ? [
      { dur: 0.6, mood: 'work', cap: 'Warned about the rock wall, the koalas know they need a ladder.', say: 'Poles for a ladder! 🪜' },
      { dur: 4.0, gather: 'poles', cap: 'Gathering materials: the koalas collect straight poles from the bush to lash into a ladder.' },
      { dur: 2.2, mood: 'work', prog: true, cap: 'Ladder lashed together, and up it goes!' },
    ] : [
      { dur: 1.2, mood: 'stuck', cap: 'A sheer rock wall! Nobody brought a ladder.', say: 'How do we get up THAT? 😰', surprise: true },
      { dur: 2.0, mood: 'work', m0y: p => -Math.sin(Math.PI * p) * 46, cap: 'One koala tries to climb with bare paws... and slides back down.', say: 'Whoooa!' },
      { dur: 5.6, gather: 'poles', lost: true, wrong: true, cap: 'They head back into the bush to find sticks, any sticks...', say: 'Need sticks! Lots of sticks!' },
      { dur: 3.4, mood: 'work', prog: true, cap: '...and lash together a wobbly ladder.' },
    ];
  }
  return [];
}

function runSeq(steps, obstacle, onDone = null) {
  const tm = S.team;
  tm.mode = 'seq'; tm.seq = steps; tm.step = 0; tm.stepT = 0; tm.stepStartX = tm.x; tm.seqOb = obstacle; tm.seqStart = S.t; tm.onDone = onDone;
  startStep();
}
function startStep() {
  const tm = S.team, st = tm.seq[tm.step], seq = tm.seq, idx = tm.step;
  if (st.cap) caption(st.cap, st.phase || (tm.seqOb ? (tm.seqOb.isSurprise ? 'SURPRISE' : 'Obstacle') : S.phase), { valid: () => tm.seq === seq && tm.step === idx || (idx === 0 && S.t - tm.seqStart < 4), hold: st.capHold, prio: st.capPrio != null ? st.capPrio : idx === 0 && tm.seqOb ? 2 : undefined });
  if (st.say) bubble('team', st.say, Math.max(2, st.dur + 0.6));
  if (st.ask) {
    const [q, a] = st.ask;
    later(0.5, () => {
      if (settings.comms) say('team', 'manager', q, a);
      else bubble('team', q + ' ...hello?', 2.6);
    });
  }
  if (st.wrong) tm.wrong++;
  if (st.surprise) tm.surprises++;
  if (st.wrong || st.surprise) stats();
  if (st.onStart) st.onStart();
}
function updateSeq(dt) {
  const tm = S.team, st = tm.seq[tm.step];
  tm.stepT += dt;
  const p = Math.min(1, tm.stepT / st.dur);
  tm.mood = st.mood || '';
  if (st.move != null) tm.x = tm.stepStartX + st.move * ease(p);
  tm.m0 = st.m0 ? st.m0(p) : 0;
  tm.m0y = st.m0y ? st.m0y(p) : 0;
  if (st.prog && tm.seqOb) tm.seqOb.prog = Math.max(tm.seqOb.prog, p);
  if (st.bushHp && tm.bush) { tm.bush.hp = lerp(st.bushHp[0], st.bushHp[1], p); if (Math.random() < dt * 14) leaf(tm.bush.x - 4, groundBase(tm.bush.x) - 14 - Math.random() * 14); }
  if (st.rev && tm.seqOb) tm.seqOb.rev = Math.max(tm.seqOb.rev, p);
  if (p >= 1 && (!st.until || st.until())) {
    tm.step++; tm.stepT = 0; tm.stepStartX = tm.x;
    if (tm.step >= tm.seq.length) {
      const o = tm.seqOb, done = tm.onDone;
      tm.seq = null; tm.seqOb = null; tm.onDone = null; tm.mode = 'walk'; tm.mood = ''; tm.m0 = 0; tm.m0y = 0;
      if (done) done();
      else if (o) obstacleCleared(o);
      else caption('Eventually the koalas pick a direction and head off, unsure if it\'s right.', 'Execution');
    } else startStep();
  }
}
function obstacleCleared(o) {
  const tm = S.team;
  o.done = true; o.prog = 1; o.active = false;
  const days = Math.max(1, Math.round((S.t - tm.seqStart) / SEC_PER_DAY));
  const Name = o.name[0].toUpperCase() + o.name.slice(1);
  if (o.isSurprise) {
    tm.cheer = 1.0;
    caption(settings.comms
      ? `Surprise handled! The ${o.name} cost ${dd(days)}, but everyone knew why and the goal stayed the same.`
      : `Handled alone: the ${o.name} cost ${dd(days)}, and nobody up top even knew.`, 'Execution');
    bubble('team', pick(CHEERS, tm.cleared + 2), 2.2);
    if (settings.comms) later(1.0, () => say('manager', 'leader', `${o.icon} ${o.name[0].toUpperCase() + o.name.slice(1)} sorted. Back on track!`, 'Great recovery, team! 🦅'));
    return;
  }
  tm.cleared++; tm.cheer = 1.0;
  if (o.informed) caption(`${Name} cleared in ${dd(days)}! The koalas push on through the undergrowth.`, 'Execution');
  else {
    const plan = Math.max(1, Math.round(sequenceFor(o, true).reduce((a, st) => a + st.dur, 0) / SEC_PER_DAY));
    caption(`${Name} cleared, but going in blind took ${dd(days)} instead of about ${dd(plan)}.`, 'Execution');
  }
  bubble('team', pick(CHEERS, tm.cleared), 2.2);
  if (o.type === 'bees' && settings.comms) { later(0.8, () => whenFree(mgFree, startRecognition)); return; }
  // Manager reports progress up; the Leader recognises the team.
  later(1.0, () => say('manager', 'leader', `${o.icon} ${o.name[0].toUpperCase() + o.name.slice(1)} cleared! ✅`, null, () => {
    if (tm.cleared % 2 === 1 || !settings.comms) bubble('leader', pick(RECOGNITION, tm.cleared >> 1), 2.8);
    else bubble('leader', 'Good progress. Keep going!', 2.4);
    if (settings.comms && o.type === 'river' && tm.lead === 0) whenFree(mgFree, () => say('manager', 'team', 'Great leading, Kip! The boss noticed. ⭐', 'Kip: Thanks! Team effort! 😊', () => { tm.lead = -1; }));
    else if (settings.comms && tm.cleared % 2 === 1) later(0.6, () => say('manager', 'team', 'The boss says great work! 🌟', 'Thanks boss! 😊'));
  }));
}

// ---------- update ----------
function update(dt) {
  S.t += dt;
  for (const e of S.events.slice()) if (S.t >= e.at) { S.events.splice(S.events.indexOf(e), 1); e.fn(); }
  for (const w of S.pend.slice()) if (w.cond()) { S.pend.splice(S.pend.indexOf(w), 1); w.fn(); }
  pumpCaptions();
  const tm = S.team, mg = S.mgr, ld = S.leader;
  tm.cheer = Math.max(0, tm.cheer - dt);
  tm.upT = Math.max(0, tm.upT - dt);
  tm.fresh = Math.max(0, tm.fresh - dt); tm.supplied = Math.max(0, tm.supplied - dt);
  for (const b of S.kb) b.t -= dt; S.kb = S.kb.filter(b => b.t > 0);
  if (S.idea.go) S.idea.goT += dt;
  if (S.leafFly) { S.leafFly.t += dt; if (S.leafFly.t > 1.0) S.leafFly = null; }
  if (S.drop) { const D = S.drop; D.t += dt; if (!D.landed && D.t >= 3.0) { D.landed = true; tm.supplied = 3.2; for (let i = 0; i < 10; i++) leaf(D.x, GROUND - 10); } if (D.sp.done) D.fade = (D.fade || 0) + dt; if (D.fade > 1) S.drop = null; }
  if (!S.finished) { const d = dayOf(S.t); if (d !== S.day) { S.day = d; call('OnDay', d); } }
  if (tm.mood === 'chisel' && Math.random() < dt * 16) { const b = ob('boulder'); S.particles.push({ kind: 'confetti', x: b.x + 4 + Math.random() * (b.w - 8), y: GROUND - 14 - Math.random() * 60, vx: -40 - Math.random() * 80, vy: -60 - Math.random() * 90, r: 0, vr: 6, life: 0.7, c: Math.random() < 0.5 ? '#8a8d91' : '#b9bcc0' }); }

  // --- team ---
  if (tm.mode === 'walk' && !S.breakDone && tm.x >= BREAK_X && !S.finished && (!settings.comms || mgFree())) startBreak();
  if (tm.mode === 'walk') {
    const next = S.obstacles.concat(S.surprises).filter(o => !o.done).sort((a, b) => a.x - b.x)[0];
    const spd = (settings.comms ? WALK_SPEED_INFORMED : WALK_SPEED_UNINFORMED) * (tm.tired ? 0.68 : 1);
    const nx = tm.x + spd * dt;
    const stopX = next ? next.x - 28 : GOAL_X - PYR_HALF - 20;
    const bush = S.pathBushes.find(b => !b.cut && !(b.lantana && S.idea.go) && b.x - 22 > tm.x - 1);
    const bushStop = bush ? bush.x - 22 : Infinity;
    tm.mood = '';
    if (bush && bushStop < stopX && nx >= bushStop) {
      tm.x = bushStop; tm.bush = bush; tm.hackT = 0;
      if (bush.coach && !S.coachDone) { S.coachDone = true; runSeq(coachSeq(), null, () => coachDone(bush)); }
      else tm.mode = 'hack';
    } else if (nx >= stopX) {
      tm.x = stopX;
      if (next) { next.active = true; runSeq(next.isSurprise ? surpriseSeq(next) : sequenceFor(next, next.informed), next); }
      else if (!ld.meeting) finish(); // wait for the Leader to wrap up any meeting, then celebrate together
    } else tm.x = nx;
  } else if (tm.mode === 'hack') {
    const b = tm.bush;
    let dur = b.lantana ? (settings.comms ? LANTANA_HACK.on : LANTANA_HACK.off) : (settings.comms ? 0.9 : 1.3);
    if (tm.tired) dur *= 1.6;
    tm.hackT += dt; tm.mood = 'hack';
    if (b.lantana && !S.idea.started) startIdea();
    if (b.lantana && S.idea.go) { tm.mode = 'walk'; tm.bush = null; } // leave the lantana for the creek route
    else {
    b.hp = Math.max(0, 1 - tm.hackT / dur);
    if (Math.random() < dt * 22) leaf(b.x - 4, groundBase(b.x) - 14 - Math.random() * 14);
    if (tm.hackT >= dur) {
      b.cut = true; tm.bush = null; tm.mode = 'walk'; tm.bushesCut++;
      for (let i = 0; i < 6; i++) leaf(b.x, groundBase(b.x) - 12);
      if (tm.bushesCut === 1 || (tm.bushesCut % 4 === 0 && S.t - S.capT > 7)) caption(pick(BUSH_LINES, tm.bushesCut >> 2), 'Everyday work');
      if (tm.bushesCut % 3 === 0 && !S.bubbles.some(x => x.who === 'team') && !b.lantana && !S.team.tired) bubble('team', pick(['Hack! 🌿', 'Another one...', 'Chop chop!', 'Snip snip!', 'Next!'], tm.bushesCut), 1.4);
    }
    }
  } else if (tm.mode === 'seq') updateSeq(dt);

  // --- distractions (triggered by team progress, only between obstacles) ---
  if (!S.finished && (tm.mode === 'walk' || tm.mode === 'hack')) {
    for (const d of S.distractions) {
      const ag = d.who === 'leader' ? ld : mg;
      if (!d.done && tm.x >= d.atX && !ag.dist && !(d.who === 'leader' && ld.meeting) && !(d.who === 'manager' && (mg.meeting || mg.task || mg.busy)) && mg.ready) { d.done = true; startDistraction(ag, d); }
    }
    for (const m of S.meetings) {
      if (!m.done && tm.x >= m.atX && !ld.dist && !ld.meeting && !mg.meeting && !S.waiters.length && mg.ready) { m.done = true; startMeeting(m); }
    }
  }
  // v4: manager meetings start while the koalas are gathering materials for that obstacle
  for (const m of S.mgrMeetings) {
    if (m.done || S.finished) continue;
    const o = ob(m.ob), st = tm.seq && tm.seq[tm.step];
    if (!m.pending && ((tm.seqOb === o && st && st.gather && tm.stepT >= 1.0) || o.done)) m.pending = true;
    if (m.pending && mgFree() && !ld.meeting && !S.waiters.length && !(tm.seqOb && tm.seqOb.isSurprise)) { m.done = true; startMgrMeeting(m); }
  }
  updateMgrMeeting(dt);
  updateDistraction(ld, dt);
  updateMeeting(dt);
  if (S.waiters.length && !ld.dist && !ld.meeting && !(ld.beam === 'creek')) S.waiters.shift()();
  updateDistraction(mg, dt);

  // --- manager: flies ahead of the team, scouting ---
  if (mg.ready && mg.task) {
    const T = mgTaskTarget(mg.task); mg.task.t += dt;
    mg.x += clamp((T.x - mg.x) * 2.6 * dt, -240 * dt, 240 * dt);
    mg.dy += clamp((T.dy - mg.dy) * 2.6 * dt, -150 * dt, 150 * dt);
  } else if (mg.ready) {
    const lead = S.finished ? 60 : 300;
    const target = Math.min(tm.x + lead, GOAL_X - 40);
    const nextUnspotted = S.obstacles.find(o => !o.spotted);
    const distracted = mg.dist && mg.dist.phase === 'distract';
    const ideaPending = S.idea.started && (settings.comms ? !S.idea.go : S.idea.bulb);
    if (!distracted && !ideaPending && nextUnspotted && mg.x + 230 >= nextUnspotted.x) spot(nextUnspotted);
    const dx = target - mg.x;
    mg.x += clamp(dx * 1.4 * dt, -140 * dt, 140 * dt);
    mg.dy += clamp(-mg.dy * 2.4 * dt, -130 * dt, 130 * dt);
  }
  mg.alert = Math.max(0, mg.alert - dt);
  mg.focusT = Math.max(0, mg.focusT - dt);
  mg.y = MANAGER_Y + mg.dy + Math.sin(S.t * 2.1) * (mg.task ? 4 : 8);

  // --- leader: soars above, roughly between team and goal ---
  const base = S.finished ? GOAL_X : clamp(Math.max(tm.x, mg.x) + 180, 300, GOAL_X - 120);
  const lx = base + Math.sin(S.t * 0.45) * 90;
  ld.x += clamp((lx - ld.x) * 1.2 * dt, -150 * dt, 150 * dt);
  ld.y = LEADER_Y + Math.sin(S.t * 1.3) * 10;
  if (ld.beamT > 0) { ld.beamT -= dt; if (ld.beamT <= 0) ld.beam = null; }

  // --- routine communication ---
  if (mg.ready && !S.finished) {
    if (S.t > S.nextLeaderTalk && !ld.dist && !ld.meeting && mgFree() && !S.waiters.length && !S.pend.length && !(tm.seqOb && tm.seqOb.isSurprise)) {
      S.nextLeaderTalk = S.t + 19;
      const [a, b] = pick(LEADER_TALK, S.leaderTalkI++);
      ld.beam = 'goal'; ld.beamT = 2.4;
      say('leader', 'manager', a, b);
    }
    if (S.t > S.nextCheckin && mgFree() && tm.mode !== 'seq' && !tm.tired && !S.pend.length) {
      S.nextCheckin = S.t + 21;
      if (settings.comms) { const [a, b] = pick(MANAGER_CHECKIN, S.checkinI++); say('manager', 'team', a, b); }
      else bubble('team', pick(LONELY, S.checkinI++), 2.6);
    }
  }

  // --- bubbles (with per-speaker queue) / pulses / particles ---
  for (const b of S.bubbles) b.t += dt;
  S.bubbles = S.bubbles.filter(b => b.t < b.dur);
  for (const who of ['leader', 'manager', 'team', 'visitor']) {
    const q = S.queue[who]; if (!q.length) continue;
    const cur = S.bubbles.find(b => b.who === who);
    if (!cur || cur.t >= MIN_SHOW) { const n = q.shift(); showBubble(who, n.text, n.dur); }
  }
  for (const p of S.pulses.slice()) {
    p.t += dt;
    if (p.t >= p.dur) { S.pulses.splice(S.pulses.indexOf(p), 1); p.onArrive && p.onArrive(); }
  }
  for (const p of S.particles) {
    if (p.kind === 'leaf') { p.vy += 60 * dt; p.vx *= 0.98; p.x += (p.vx + Math.sin(p.life * 6) * 20) * dt; }
    else { p.vy += 160 * dt; p.x += p.vx * dt; }
    p.y += p.vy * dt; p.r += p.vr * dt; p.life -= dt;
  }
  S.particles = S.particles.filter(p => p.life > 0);
  for (const o of S.obstacles) o.angry = Math.max(0, o.angry - dt);
  if (S.finished && Math.random() < dt * 30) confetti(GOAL_X + (Math.random() - 0.5) * 300, 60 + Math.random() * 60, 1);
}

function startDistraction(ag, d) {
  ag.dist = { def: d, t: 0, phase: 'distract', last: { ox: 0, oy: 0, rot: 0 } };
  caption(d.cap, 'Distraction');
  bubble(d.who, d.say, 2.4, true);
  later(1.8, () => bubble(d.who, d.say2, 1.9, true));
}
const D_DISTRACT = 3.6, D_REFOCUS = 2.0;
function updateDistraction(ag, dt) {
  const d = ag.dist;
  if (!d) { ag.ox = 0; ag.oy = 0; ag.rot = 0; return; }
  d.t += dt;
  const t = S.t;
  if (d.phase === 'distract') {
    const p = Math.min(1, d.t / D_DISTRACT), env = Math.sin(Math.PI * Math.min(1, p * 1.25)) * 0.6 + 0.4 * (p < 0.9 ? 1 : 0);
    let ox = 0, oy = 0, rot = 0;
    switch (d.def.kind) {
      case 'magpie': ox = -40 * env; oy = Math.sin(t * 9) * 10 + 22 * env; rot = Math.sin(t * 8) * 0.28; break;
      case 'email': ox = -60 * env; oy = Math.sin(t * 3) * 5; rot = 0.12 * env; break;
      case 'storm': ox = -150 * Math.sin(Math.PI * p * 0.5); oy = Math.sin(t * 6) * 14; rot = Math.sin(t * 5) * 0.4; break;
      case 'meeting': ox = -70 * env; oy = 6 * env; rot = -0.1 * env; break;
      case 'mosquito': ox = Math.sin(t * 13) * 9; oy = Math.cos(t * 11) * 9; rot = Math.sin(t * 14) * 0.22; break;
      case 'branch': ox = -26 * env; oy = 16 * env; rot = Math.sin(t * 6) * 0.5 * env; break;
    }
    ag.ox = ox; ag.oy = oy; ag.rot = rot; d.last = { ox, oy, rot };
    if (d.t >= D_DISTRACT) {
      d.phase = 'refocus'; d.t = 0;
      bubble(d.def.who, d.def.refocus, 2.6, true);
      if (d.def.who === 'leader') {
        S.leader.beam = 'goal'; S.leader.beamT = 2.4;
        caption('The Leader refocuses on the pyramid. Distractions happen; what matters is getting back to the main objective.', 'Refocus');
      } else {
        S.mgr.focusT = 2.0;
        caption('The Manager shakes off the distraction and gets back to planning and guiding the team.', 'Refocus');
      }
    }
  } else {
    const q = ease(Math.min(1, d.t / D_REFOCUS));
    ag.ox = d.last.ox * (1 - q); ag.oy = d.last.oy * (1 - q); ag.rot = d.last.rot * (1 - q);
    if (d.t >= D_REFOCUS) { ag.dist = null; S.team.distractions++; stats(); }
  }
}

function spot(o) {
  o.spotted = true;
  S.mgr.alert = 2.2;
  bubble('manager', `${o.icon} ${o.name[0].toUpperCase() + o.name.slice(1)} ahead!`, 2.6);
  if (settings.comms) {
    caption(`The Manager spots a ${o.name} ahead and radios a warning down to the koalas.`, 'Communication');
    const advice = {
      vines: ['Heads up: vines ahead, bring cutting tools!', 'Tools ready! ✂️'],
      boulder: ['Boulder ahead, too big to go round. Training and hammers on the way! 🔨', 'New skills? Yes please! 🎓'],
      river: ['River ahead: gather logs for a bridge!', 'We\'ll fan out for logs! 🪵'],
      bog: ['Bog ahead: you\'ll need flat stones!', 'Stone hunt! 🪨'],
      log: ['Big log ahead: there\'s a hollow you can crawl through!', 'Ooh, a tunnel! 🐨'],
      cliff: ['Cliff ahead: braid a rope and climb down at the marked spot!', 'Vine rope it is! 🪢'],
      bees: ['Bees\' nest ahead: tiptoe quietly!', '(whispering) Okay... 🤫'],
      wall: ['Rock wall ahead: gather poles for a ladder!', 'Poles it is! 🪜'],
    }[o.type];
    later(0.8, () => say('manager', 'team', '📻 ' + advice[0], advice[1], () => { o.informed = true; }));
  } else {
    caption(`The Manager spots a ${o.name}, but communication is OFF, so the koalas never hear about it.`, 'No communication');
    later(1.2, () => bubble('manager', '(...keeps it to themselves 🤐)', 2.4));
  }
}

function finish() {
  const tm = S.team;
  S.finished = true; tm.mode = 'done'; tm.mood = 'happy';
  caption(`Delivered on day ${Math.ceil(S.t / SEC_PER_DAY)}! 🎉 The koalas reach the pyramid: vision (Leader) + planning & communication (Manager) + everyday hard work (Team).`, 'Goal reached', { force: true });
  S.mgr.task = null; S.mgr.busy = false;
  bubble('team', 'We made it!! 🎉🐨', 5);
  later(1.0, () => bubble('manager', 'Brilliant work, koalas! 🦉', 4));
  later(1.8, () => bubble('leader', 'Proud of every one of you! 🦅', 4));
  later(4.6, () => bubble('team', 'Group hug!! 🤗', 4));
  for (let i = 0; i < 80; i++) confetti(tm.x - 30 + (Math.random() - 0.5) * 60, memberY(tm.x) - 50, 1);
  const days = Math.ceil(S.t / SEC_PER_DAY); S.day = days; call('OnDay', days);
  call('OnFinished', Math.round(S.t), days, tm.wrong, tm.surprises, tm.distractions, tm.priorities, tm.reported, tm.syncs, tm.ideas, tm.breaks, settings.comms);
}
function confetti(x, y, n) {
  const cols = ['#ff5d5d', '#ffd34d', '#5dd3ff', '#8aff5d', '#d07bff', '#ffffff'];
  for (let i = 0; i < n; i++) S.particles.push({ kind: 'confetti', x, y, vx: (Math.random() - 0.5) * 220, vy: -120 - Math.random() * 200, r: Math.random() * 6, vr: (Math.random() - 0.5) * 10, life: 2.5 + Math.random(), c: cols[Math.floor(Math.random() * cols.length)] });
}
function leaf(x, y) {
  const cols = ['#4caf50', '#66bb6a', '#2e7d32', '#9ccc65'];
  S.particles.push({ kind: 'leaf', x, y, vx: 30 + Math.random() * 90, vy: -60 - Math.random() * 80, r: Math.random() * 6, vr: (Math.random() - 0.5) * 8, life: 1.1 + Math.random() * 0.6, c: cols[Math.floor(Math.random() * 4)] });
}

// ---------- v5: growing people, ideas from the ground, wellbeing ----------
// Where the owl goes when it drops down to the koalas (dy is how far below its usual flight line).
function mgTaskTarget(T) {
  const tm = S.team, kx = i => (S.kpos[i] ? S.kpos[i].x : tm.x - i * MEMBER_GAP);
  if (T.kind === 'coach') return { x: kx(3) - 84, dy: 80 };
  if (T.kind === 'recog') return { x: tm.x + 95, dy: 56 };
  return { x: tm.x + 92, dy: 66 }; // break
}
// Wattle (the smallest koala) struggles with her saw at a thick bush. ON: the owl coaches her. OFF: nobody notices.
function coachSeq() {
  const tm = S.team;
  if (settings.comms) return [
    { dur: 2.0, mood: 'hack', struggle: true, bushHp: [1, 0.8], phase: 'COACHING', until: mgFree,
      cap: 'The everyday work, but Wattle, the smallest koala, is struggling: her saw keeps getting stuck and she\'s falling behind.', say: 'Wattle: My saw keeps getting stuck... 😣' },
    { dur: 2.9, mood: 'hack', struggle: true, bushHp: [0.8, 0.6], phase: 'COACHING', cap: 'Managers grow people: the owl drops down to coach Wattle one-to-one.',
      onStart: () => { S.mgr.task = { kind: 'coach', t: 0 }; later(0.7, () => bubble('manager', 'You\'ve got this, Wattle! Hold it like this. ✂️', 2.4, true)); } },
    { dur: 2.0, mood: 'hack', bushHp: [0.6, 0], phase: 'COACHING', cap: 'A little coaching and Wattle cuts as well as anyone. A small investment that lasts the whole journey.',
      say: 'Wattle: Oh! That\'s so much easier! 😊', onStart: () => { tm.coached = true; kbadge(3, '💪 Wattle: coached!', 4.5, '#b9f6ca'); S.mgr.task = null; S.mgr.focusT = 1.6; } },
  ];
  return [
    { dur: 2.0, mood: 'hack', struggle: true, bushHp: [1, 0.7], phase: 'Everyday work', capPrio: 2,
      cap: 'Wattle, the smallest koala, is struggling: her saw keeps getting stuck and she\'s falling behind.', say: 'Wattle: My saw keeps getting stuck... 😣' },
    { dur: 2.6, mood: 'hack', struggle: true, bushHp: [0.7, 0], phase: 'No communication',
      cap: 'Nobody notices. With communication OFF there\'s no one to coach her, so Wattle just keeps struggling.', say: 'Wattle: Am I doing this right? ...anyone? 😓' },
  ];
}
function coachDone(bush) {
  const tm = S.team;
  bush.cut = true; tm.bush = null; tm.bushesCut++;
  for (let i = 0; i < 6; i++) leaf(bush.x, groundBase(bush.x) - 12);
  if (S.mgr.task && S.mgr.task.kind === 'coach') { S.mgr.task = null; S.mgr.focusT = 1.6; }
}
// Banjo spots a dry creek bed beside the lantana. ON: the idea goes up, the Leader adopts it and changes course.
function startIdea() {
  const I = S.idea; I.started = true; I.bulb = true;
  if (settings.comms) whenFree(() => mgFree() && !S.bubbles.some(b => b.who !== 'visitor') && !S.queue.team.length && !S.queue.manager.length, () => {
    caption('Team members lead too: hacking through thick lantana, Banjo spots a dry creek bed running alongside. A better route, seen from the ground!', 'TEAM IDEA', { hold: 3.2 });
    bubble('team', 'Banjo: There\'s a shortcut along the creek bed! 💡', 2.8, true);
    whenFree(mgFree, () => {
      S.mgr.busy = true;
      later(0.4, () => say('team', 'manager', 'Banjo: A dry creek bed skips all this lantana!', 'Smart! Taking it to the boss. 🦉', () => {
        caption('Ideas travel up too: the Manager passes Banjo\'s idea straight to the Leader.', 'TEAM IDEA');
        S.waiters.push(() => say('manager', 'leader', 'The team found a creek route that skips the lantana.', null, adoptIdea));
      }));
    });
  }); else {
    caption('Banjo spots a dry creek bed that would skip the lantana, but with communication OFF the idea goes nowhere.', 'No communication', { hold: 3 });
    bubble('team', 'Banjo: Psst... a creek bed! Should we tell someone? 🤔', 3, true);
    later(3.4, () => bubble('team', 'Banjo: ...hello? Guess we keep hacking. 😕', 2.6));
    later(6.2, () => { I.bulb = false; });
  }
}
function adoptIdea() {
  const I = S.idea, tm = S.team;
  const left = S.pathBushes.filter(b => b.lantana && !b.cut).length;
  const days = Math.max(1, Math.round((left - 1.3) * LANTANA_HACK.on / SEC_PER_DAY));
  I.adopted = true; I.saved = days; tm.ideas++; stats();
  S.leader.beam = 'creek'; S.leader.beamT = 5.5;
  bubble('leader', `New info from the ground. We'll take the creek route; it saves ${days} days.`, 3.6, true);
  caption(`Course correction: leaders adapt. With new information from the ground, the Leader changes the plan: the creek route saves about ${days} days.`, 'COURSE CORRECTION', { force: true, hold: 3.6 });
  later(2.0, () => pulse('leader', 'manager', PULSE_COL.leader, () => say('manager', 'team', 'Creek route approved! Great idea, Banjo! 🌟', 'Banjo: Woohoo! Follow me! 🐨', () => {
    I.go = true; I.bulb = false; S.mgr.busy = false;
    kbadge(1, '💡 Banjo: idea adopted!', 5, '#b3e5fc');
    caption('Credit flows back down: the koalas leave the lantana behind and follow Banjo along the creek bed.', 'COURSE CORRECTION');
  })));
}
// Small wins: Matilda gets a gum leaf, "Koala of the week".
function startRecognition() {
  const mg = S.mgr, tm = S.team;
  mg.task = { kind: 'recog', t: 0 };
  caption('Celebrating small wins: the owl names Matilda "Koala of the week" for keeping everyone calm past the bees. 🌿', 'RECOGNITION', { hold: 3.4 });
  later(1.0, () => bubble('manager', 'Koala of the week: Matilda! 🌿 You kept us calm.', 2.6, true));
  later(1.7, () => { S.leafFly = { t: 0 }; });
  later(2.7, () => { tm.leaf = 2; kbadge(2, '🌿 Matilda: Koala of the week', 4.5, '#c5e1a5'); bubble('team', 'Matilda: Aww, thanks! 🥰', 2.2); });
  later(4.4, () => { mg.task = null; mg.focusT = 1.4; say('manager', 'leader', '🐝 Bees\' nest cleared! ✅ Matilda kept everyone calm.', 'Great work, Matilda! 🦅'); });
}
// Wellbeing: after the toughest stretch. ON: the owl calls a break. OFF: no break, and the koalas tire.
function startBreak() {
  const tm = S.team; S.breakDone = true;
  if (!settings.comms) {
    tm.tired = true;
    caption('Nobody calls a break. After the toughest stretch of the journey, the koalas push on exhausted, and slow right down.', 'WELLBEING', { hold: 3.5 });
    bubble('team', 'So... tired... 😓', 2.8, true);
    later(5, () => bubble('team', 'Can we stop yet? 💦', 2.4));
    return;
  }
  const t0 = S.t;
  runSeq([
    { dur: 2.4, mood: '', move: 110, phase: 'WELLBEING', cap: 'Trust and wellbeing: after the cliff, the bees, the snake and the rock wall, the owl calls a break.',
      onStart: () => { S.mgr.task = { kind: 'break', t: 0 }; later(0.3, () => bubble('manager', 'Tough stretch! Take five, team. 💧', 2.6, true)); } },
    { dur: 3.9, mood: 'rest', rest: true, phase: 'WELLBEING', cap: 'Water from the billy and a eucalyptus snack. A sustainable pace beats burnout.',
      onStart: () => later(0.9, () => bubble('team', 'Ahh, billy tea and gum leaves! 🌿', 2.6)) },
    { dur: 0.9, mood: '', phase: 'WELLBEING', onStart: () => { tm.breaks++; tm.fresh = 3.2; } },
  ], null, () => {
    S.mgr.task = null; S.mgr.focusT = 1.4;
    caption(`Break over: it cost about ${dd(Math.max(1, Math.round((S.t - t0) / SEC_PER_DAY)))}, and the koalas set off refreshed. ⚡`, 'WELLBEING');
  });
}

// ---------- v3: surprise delays (bottom-up communication) ----------
function surpriseSeq(sp) {
  const snake = sp.type === 'snake';
  const first = { dur: 1.6, mood: 'stuck', cap: sp.reveal, say: sp.revSay, rev: true, phase: 'SURPRISE' };
  if (settings.comms) return [
    first,
    { dur: 1.0, mood: '', until: () => sp.chainDone, onStart: () => upChain(sp) },
    ...(sp.type === 'sinkhole' ? [{ dur: 3.6, gather: 'planks', cap: sp.gatherCap }] : []),
    { dur: snake ? 2.6 : 3.2, mood: snake ? 'sneak' : 'work', prog: true, cap: sp.fixCap },
  ];
  return [
    first,
    { dur: 2.2, mood: 'confused', cap: 'The koalas call up for help... but with communication OFF, nobody answers.', say: sp.up + ' ...hello?' },
    sp.type === 'sinkhole'
      ? { dur: 5.2, gather: 'planks', lost: true, wrong: true, say: 'Guess we\'re on our own... 😟', cap: 'On their own, the koalas search the bush for anything to bridge the hole...' }
      : { dur: 2.0, mood: 'confused', move: -70, wrong: true, say: 'Guess we\'re on our own... 😟' },
    ...(sp.type === 'sinkhole' ? [] : [{ dur: 1.6, mood: 'walk', move: 70 }]),
    { dur: 4.4, mood: snake ? 'sneak' : 'work', prog: true, cap: sp.aloneCap },
  ];
}
// Team -> Manager -> Leader, then the Leader's answer travels back down.
function upChain(sp) {
  caption('Bottom-up communication: the koalas report the surprise straight up to the Manager.', 'SURPRISE');
  say('team', 'manager', sp.up, sp.ack, () => {
    S.waiters.push(() => {
      caption('The Manager escalates it to the Leader: what happened, what the team needs, and the likely delay.', 'SURPRISE');
      say('manager', 'leader', sp.toLeader, sp.leaderReply, () => {
        S.team.reported++; stats();
        S.leader.beam = 'goal'; S.leader.beamT = 2.6;
        const down = () => pulse('leader', 'manager', PULSE_COL.leader, () => say('manager', 'team', sp.down, sp.teamAck, () => { sp.chainDone = true; }));
        if (sp.support) {
          caption('Leaders back the team: the Leader says YES to saws and safety gear, and a supply drop floats down through a gap in the canopy. 🪂', 'LEADER SUPPORT', { hold: 4 });
          S.drop = { x: S.team.x - 160, t: 0, landed: false, sp };
          whenFree(() => S.drop && S.drop.landed, () => later(0.5, down));
        } else {
          caption('The Leader accepts the delay and reassures everyone: safety first, the goal stays the same.', 'SURPRISE');
          later(0.8, down);
        }
      });
    });
  });
}

// ---------- v4: manager meetings (sideways coordination under the canopy) ----------
function startMgrMeeting(m) {
  S.mgr.meeting = { def: m, phase: 'arrive', t: 0, li: 0 };
  caption(`Manager meeting: ${m.who} owl flies in under the canopy ${m.topic}. Managers coordinate sideways too.`, 'Manager meeting', { force: true, hold: () => S.mgr.meeting && S.mgr.meeting.phase !== 'leave' });
}
function updateMgrMeeting(dt) {
  const M = S.mgr.meeting; if (!M) return;
  M.t += dt;
  if (M.phase === 'talk') {
    while (M.li < M.def.lines.length && M.t >= M.li * MM_LINE_GAP) { const [w, txt] = M.def.lines[M.li++]; bubble(w, txt, 2.3); }
  }
  if (M.t >= MM_PHASES[M.phase]) {
    M.t = 0;
    if (M.phase === 'arrive') M.phase = 'talk';
    else if (M.phase === 'talk') {
      M.phase = 'leave';
      S.team.syncs++; stats();
      S.mgr.focusT = 2.0;
      caption('The visiting owl flies off, and the Manager refocuses on the koalas. 🐨', 'Refocus');
    } else S.mgr.meeting = null;
  }
}
function mgrVisitorPos() {
  const M = S.mgr.meeting, bx = S.mgr.x + 205, by = MANAGER_Y + 46 + Math.sin(S.t * 2.4) * 5;
  const p = Math.min(1, M.t / MM_PHASES[M.phase]);
  if (M.phase === 'arrive') { const q = ease(p); return { x: bx + (1 - q) * 560, y: by - (1 - q) * (1 - q) * 130 }; }
  if (M.phase === 'leave') { const q = ease(p); return { x: bx + q * 600, y: by - q * q * 150 }; }
  return { x: bx, y: by };
}

// ---------- v3: leader meetings (competing priorities) ----------
function startMeeting(m) {
  S.leader.meeting = { def: m, phase: 'arrive', t: 0, cards: m.visitors.map(() => ({ shown: false, state: 'pending' })) };
  caption(`Meeting time! Eagles from ${m.who} fly in above the canopy, each with their own priority.`, 'Meeting', { hold: () => S.leader.meeting && S.leader.meeting.phase === 'arrive' });
}
function updateMeeting(dt) {
  const M = S.leader.meeting; if (!M) return;
  M.t += dt;
  const d = M.def;
  if (M.phase === 'ask') {
    M.cards.forEach((c, i) => { if (!c.shown && M.t >= i * 0.8) c.shown = true; });
  } else if (M.phase === 'decide') {
    const yi = d.visitors.findIndex(v => v.accept);
    if (M.t >= 0.3 && M.cards[yi].state === 'pending') { M.cards[yi].state = 'yes'; bubble('leader', d.yes, 2.4, true); }
    if (M.t >= 1.5 && M.cards.some(c => c.state === 'pending')) {
      let n = 0; M.cards.forEach(c => { if (c.state === 'pending') { c.state = 'parked'; n++; } });
      S.team.priorities += n; stats();
      bubble('leader', d.no, 2.6, true);
    }
  }
  if (M.t >= MEETING_PHASES[M.phase]) {
    M.t = 0;
    if (M.phase === 'arrive') {
      M.phase = 'ask';
      caption('Everyone wants something: lots of competing priorities land on the Leader at once.', 'Meeting', { hold: () => S.leader.meeting && S.leader.meeting.phase === 'ask' });
      M.cards.forEach(c => c.shown = false);
    } else if (M.phase === 'ask') {
      M.phase = 'decide';
      if (d.support) caption(d.support, 'LEADER SUPPORT', { hold: () => S.leader.meeting && S.leader.meeting.phase === 'decide' });
      else caption('The Leader weighs them up: yes to what supports the pyramid, "not now" to the rest.', 'Priorities', { hold: () => S.leader.meeting && S.leader.meeting.phase === 'decide' });
    } else if (M.phase === 'decide') {
      M.phase = 'leave';
      S.leader.beam = 'goal'; S.leader.beamT = 3.0;
      caption('The visiting eagles fly off. The Leader keeps the beam on the goal and keeps it going. 🔺', 'Focus');
    } else {
      S.leader.meeting = null;
      bubble('leader', 'Keep it going. Eyes on the pyramid. 🔺', 2.4);
    }
  }
}
const MEETING_SLOTS = [[-200, 16], [200, 16], [-420, 30]];
function visitorPos(M, i) {
  const L = S.leader, [sx, sy] = MEETING_SLOTS[i];
  const bx = L.x + L.ox, by = L.y + L.oy;
  const p = Math.min(1, M.t / MEETING_PHASES[M.phase]);
  if (M.phase === 'arrive') { // spiral in, circling the leader
    const q = ease(p), a = (1 - q) * 6 + i * 2.1, R = (1 - q) * 260;
    return { x: bx + sx + Math.cos(a) * R + (1 - q) * (1 - q) * 700, y: by + sy + Math.sin(a) * R * 0.3 - (1 - q) * (1 - q) * 110 };
  }
  if (M.phase === 'leave') { const q = ease(p); return { x: bx + sx + q * 800, y: by + sy - q * 170 }; }
  return { x: bx + sx + Math.sin(S.t * 1.5 + i) * 6, y: by + sy + Math.sin(S.t * 2 + i) * 5 };
}

// ---------- camera ----------
function updateCamera(dt) {
  if (S.introCam === 'start') camTarget = 0;
  else if (S.introCam === 'goal') camTarget = GOAL_X + 260 - viewW;
  else if (S.finished) camTarget = GOAL_X + 300 - viewW;
  else camTarget = S.team.x - viewW * 0.3;
  camTarget = clamp(camTarget, 0, Math.max(0, WORLD_W - viewW));
  camX += (camTarget - camX) * Math.min(1, dt * 2.2);
}
// ---------- drawing (scene pieces kept from v1) ----------
function drawSky() {
  const g = ctx.createLinearGradient(0, 0, 0, CANOPY_BOTTOM);
  g.addColorStop(0, '#6ec6ff'); g.addColorStop(0.7, '#bfe8ff'); g.addColorStop(1, '#e8f7e0');
  ctx.fillStyle = g; ctx.fillRect(0, 0, viewW, H);
  // sun
  ctx.fillStyle = 'rgba(255,240,170,0.9)';
  ctx.beginPath(); ctx.arc(viewW - 120, 60, 30, 0, 7); ctx.fill();
  ctx.fillStyle = 'rgba(255,240,170,0.25)';
  ctx.beginPath(); ctx.arc(viewW - 120, 60, 50, 0, 7); ctx.fill();
  // clouds (slow parallax)
  for (const c of deco.clouds) {
    const x = ((c.x - camX * 0.1 + S.t * 6 * c.s) % (viewW + 300) + viewW + 300) % (viewW + 300) - 150;
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.beginPath();
    ctx.ellipse(x, c.y, 40 * c.s, 13 * c.s, 0, 0, 7);
    ctx.ellipse(x + 25 * c.s, c.y - 8 * c.s, 26 * c.s, 14 * c.s, 0, 0, 7);
    ctx.ellipse(x - 22 * c.s, c.y - 4 * c.s, 22 * c.s, 11 * c.s, 0, 0, 7);
    ctx.fill();
  }
}

function drawUnderstory() {
  // dim green air beneath the canopy
  const g = ctx.createLinearGradient(0, CANOPY_TOP + 60, 0, LOW_GROUND);
  g.addColorStop(0, '#3e6b43'); g.addColorStop(0.5, '#4d7d4a'); g.addColorStop(1, '#2f5233');
  ctx.fillStyle = g; ctx.fillRect(0, CANOPY_TOP + 60, viewW, H);
  // far trunks (parallax 0.5)
  ctx.fillStyle = 'rgba(36,70,40,0.75)';
  for (const f of deco.far) {
    const x = f.x - camX * 0.5;
    if (x < -60 || x > viewW + 60) continue;
    ctx.fillRect(x, CANOPY_BOTTOM - 20, f.w * 0.5, GROUND - CANOPY_BOTTOM + 40);
  }
  // light shafts
  for (const s of deco.shafts) {
    const x = s.x - camX;
    if (x < -200 || x > viewW + 200) continue;
    ctx.fillStyle = 'rgba(255,250,200,0.07)';
    ctx.beginPath(); ctx.moveTo(x, CANOPY_BOTTOM - 20); ctx.lineTo(x + s.w, CANOPY_BOTTOM - 20);
    ctx.lineTo(x + s.w + 90, GROUND); ctx.lineTo(x + 60, GROUND); ctx.closePath(); ctx.fill();
  }
}

function drawTrunks() {
  for (const t of deco.trunks) {
    const x = t.x - camX;
    if (x < -50 || x > viewW + 50) continue;
    const gy = groundBase(t.x);
    const g = ctx.createLinearGradient(x, 0, x + t.w, 0);
    const base = t.shade > 0.5 ? ['#5b3e2b', '#7a5640'] : ['#4e3626', '#6d4b36'];
    g.addColorStop(0, base[0]); g.addColorStop(0.6, base[1]); g.addColorStop(1, base[0]);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x, CANOPY_TOP + 40); ctx.lineTo(x + t.w, CANOPY_TOP + 40);
    ctx.lineTo(x + t.w + 6, gy + 4); ctx.lineTo(x - 6, gy + 4); ctx.closePath(); ctx.fill();
    // roots
    ctx.beginPath(); ctx.moveTo(x - 6, gy + 4); ctx.quadraticCurveTo(x - 16, gy + 2, x - 22, gy + 6); ctx.lineTo(x, gy - 4); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x + t.w + 6, gy + 4); ctx.quadraticCurveTo(x + t.w + 16, gy + 2, x + t.w + 22, gy + 6); ctx.lineTo(x + t.w, gy - 4); ctx.fill();
  }
}

function drawHangingVines() {
  ctx.strokeStyle = '#2e6b2a'; ctx.lineWidth = 2.2;
  for (const v of deco.hang) {
    const x = v.x - camX;
    if (x < -30 || x > viewW + 30) continue;
    const sway = Math.sin(S.t * 1.2 + v.ph) * 6;
    ctx.beginPath(); ctx.moveTo(x, CANOPY_BOTTOM - 25);
    ctx.quadraticCurveTo(x + sway, CANOPY_BOTTOM - 25 + v.len * 0.6, x + sway * 1.5, CANOPY_BOTTOM - 25 + v.len);
    ctx.stroke();
    ctx.fillStyle = '#3f8f3a';
    for (let k = 0.3; k < 1; k += 0.25) {
      ctx.beginPath(); ctx.ellipse(x + sway * k * 1.4 + 3, CANOPY_BOTTOM - 25 + v.len * k, 4, 2, 0.6, 0, 7); ctx.fill();
    }
  }
}

function drawStartCamp() {
  const x = START_X - camX;
  if (x < -100 || x > viewW + 100) return;
  ctx.fillStyle = '#d0603a';
  ctx.beginPath(); ctx.moveTo(x - 40, GROUND); ctx.lineTo(x, GROUND - 46); ctx.lineTo(x + 40, GROUND); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#8a3a20';
  ctx.beginPath(); ctx.moveTo(x - 8, GROUND); ctx.lineTo(x, GROUND - 30); ctx.lineTo(x + 8, GROUND); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#3a2a1a'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(x - 70, GROUND); ctx.lineTo(x - 70, GROUND - 70); ctx.stroke();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.moveTo(x - 70, GROUND - 70); ctx.lineTo(x - 30, GROUND - 62); ctx.lineTo(x - 70, GROUND - 52); ctx.fill();
  ctx.fillStyle = '#2d2d2d'; ctx.font = 'bold 9px sans-serif'; ctx.fillText('START', x - 67, GROUND - 58);
}

function drawRiver(front) {
  const r = ob('river');
  const x = r.x - camX;
  if (x > viewW + 20 || x + r.w < -20) return;
  if (!front) {
    ctx.fillStyle = '#2f7fbf';
    ctx.fillRect(x + 4, GROUND + 18, r.w - 8, H - GROUND);
  } else {
    // front water surface over anything wading
    ctx.fillStyle = 'rgba(60,150,220,0.75)';
    ctx.fillRect(x + 6, GROUND + 16, r.w - 12, H - GROUND);
    ctx.strokeStyle = 'rgba(220,245,255,0.8)'; ctx.lineWidth = 2;
    for (let k = 0; k < 4; k++) {
      ctx.beginPath();
      for (let i = 0; i <= 20; i++) {
        const wx = x + 10 + i * (r.w - 20) / 20;
        const wy = GROUND + 22 + k * 18 + Math.sin(S.t * 4 + i * 0.9 + k) * 2.5;
        i ? ctx.lineTo(wx, wy) : ctx.moveTo(wx, wy);
      }
      ctx.stroke();
    }
    // bridge
    const planks = Math.floor(r.prog * 10 + 0.0001);
    ctx.fillStyle = '#8b5a2b'; ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = 1;
    for (let i = 0; i < planks; i++) {
      const px = x - 6 + i * (r.w + 12) / 10;
      ctx.fillRect(px, GROUND - 6, (r.w + 12) / 10 - 2, 9); ctx.strokeRect(px, GROUND - 6, (r.w + 12) / 10 - 2, 9);
    }
    if (r.prog >= 1) {
      ctx.strokeStyle = '#c9a36b'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x - 6, GROUND - 26); ctx.quadraticCurveTo(x + r.w / 2, GROUND - 14, x + r.w + 6, GROUND - 26); ctx.stroke();
      ctx.fillStyle = '#5a3a1a'; ctx.fillRect(x - 8, GROUND - 28, 4, 24); ctx.fillRect(x + r.w + 4, GROUND - 28, 4, 24);
    }
    // splash when someone wades
    if (S.team.m0 > 5 && S.team.seqOb && S.team.seqOb.type === 'river') {
      const sx = S.team.x + S.team.m0 - camX;
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.arc(sx + Math.sin(S.t * 9 + i) * 14, GROUND + 14 - Math.abs(Math.cos(S.t * 7 + i)) * 12, 2.5, 0, 7); ctx.fill(); }
    }
  }
}

function drawGround() {
  const r = ob('river');
  const x0 = camX - 20, x1 = camX + viewW + 20;
  const g = ctx.createLinearGradient(0, GROUND - 10, 0, H);
  g.addColorStop(0, '#5c8f3a'); g.addColorStop(0.15, '#6b4f2e'); g.addColorStop(1, '#3d2b18');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(x0 - camX, H);
  for (let x = x0; x <= x1; x += 6) {
    if (x > r.x && x < r.x + r.w) { // river gap
      ctx.lineTo(r.x - camX, groundBase(r.x)); ctx.lineTo(r.x + 10 - camX, H);
      ctx.lineTo(r.x + r.w - 10 - camX, H); ctx.lineTo(r.x + r.w - camX, groundBase(r.x + r.w));
      x = r.x + r.w; continue;
    }
    ctx.lineTo(x - camX, groundBase(x));
  }
  ctx.lineTo(x1 - camX, H); ctx.closePath(); ctx.fill();
  // grass tufts
  ctx.strokeStyle = '#7fbf4a'; ctx.lineWidth = 1.5;
  for (const t of deco.tufts) {
    if (t.x < x0 || t.x > x1 || (t.x > r.x && t.x < r.x + r.w)) continue;
    const gy = groundBase(t.x), sx = t.x - camX;
    ctx.beginPath(); ctx.moveTo(sx, gy); ctx.lineTo(sx - 2, gy - t.h); ctx.moveTo(sx, gy); ctx.lineTo(sx + 3, gy - t.h * 0.8); ctx.stroke();
  }
}

// v4: the koalas break the boulder down: cracks, then it splits into chunks, then rubble.
const CRACKS = [[[0.5, -104], [0.45, -82], [0.53, -64], [0.46, -42]], [[0.12, -46], [0.27, -44], [0.36, -28]], [[0.86, -62], [0.72, -54], [0.67, -36], [0.73, -14]],
  [[0.46, -42], [0.38, -22], [0.44, 0]], [[0.3, -88], [0.37, -70], [0.33, -58]], [[0.6, -20], [0.72, -8]]];
function drawRubble() {
  const b = ob('boulder'); if (!b.done) return;
  const x = b.x - camX; if (x > viewW + 80 || x + b.w < -80) return;
  // v5: the koalas sweep the rubble aside, so it stays visible beside the path instead of under their feet
  for (let k = 0; k < 16; k++) {
    const rx = x - 40 + ((k * 37) % 100) / 100 * (b.w + 80), rs = 7 + (k * 13) % 8, ry = GROUND + 30 + ((k * 23) % 3) * 7;
    ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.beginPath(); ctx.ellipse(rx + 2, ry + 2, rs, rs * 0.4, 0, 0, 7); ctx.fill();
    ctx.fillStyle = k % 2 ? '#8a8d91' : '#a6a9ad'; ctx.beginPath(); ctx.ellipse(rx, ry - rs * 0.45, rs, rs * 0.7, 0, 0, 7); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.22)'; ctx.beginPath(); ctx.ellipse(rx - rs * 0.3, ry - rs * 0.7, rs * 0.4, rs * 0.25, 0, 0, 7); ctx.fill();
  }
}
// v5: a dry creek bed runs beside the lantana. It was always there; only the koalas could see it.
function drawCreek() {
  const x0 = CREEK.x0 - camX, x1 = CREEK.x1 - camX; if (x1 < -40 || x0 > viewW + 40) return;
  const top = GROUND + 14, w = x1 - x0;
  ctx.fillStyle = '#c9ad7a';
  ctx.beginPath(); ctx.moveTo(x0, top + 12);
  ctx.bezierCurveTo(x0 + 30, top - 2, x0 + 60, top, x0 + 90, top); ctx.lineTo(x1 - 90, top);
  ctx.bezierCurveTo(x1 - 60, top, x1 - 30, top - 2, x1, top + 12);
  ctx.bezierCurveTo(x1 - 40, top + 34, x0 + 40, top + 34, x0, top + 12); ctx.fill();
  ctx.strokeStyle = 'rgba(120,180,230,0.75)'; ctx.lineWidth = 2.2; ctx.beginPath();
  for (let k = 0; k <= 40; k++) { const px = x0 + 50 + k / 40 * (w - 100), py = top + 15 + Math.sin(k * 0.7 + S.t * 1.5) * 2; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
  ctx.stroke();
  const r = rng(5);
  for (let k = 0; k < 22; k++) { const px = x0 + 30 + r() * (w - 60), py = top + 6 + r() * 18, rs = 2 + r() * 3; ctx.fillStyle = k % 2 ? '#9e8a68' : '#b8a27e'; ctx.beginPath(); ctx.ellipse(px, py, rs, rs * 0.7, 0, 0, 7); ctx.fill(); }
  if (S.idea.adopted && !S.finished) { ctx.font = 'bold 10px system-ui, sans-serif'; tag(x0 + 70, top + 40, 'CREEK ROUTE', '#b3e5fc'); }
}
// Thick lantana scrub (an invasive weed, very Australian) on the planned route.
function drawLantana() {
  for (const b of S.pathBushes) {
    if (!b.lantana) continue;
    const x = b.x - camX; if (x < -50 || x > viewW + 50) continue;
    const gy = GROUND + 3;
    if (b.cut) { ctx.fillStyle = '#6d4c2f'; ctx.fillRect(x - 6, gy - 10, 4, 10); ctx.fillRect(x + 3, gy - 12, 4, 12); continue; }
    const k = 1.5 * b.s * (0.4 + 0.6 * b.hp), wob = b.hp < 1 && S.team.bush === b ? Math.sin(S.t * 40) * 1.5 : 0;
    ctx.fillStyle = '#2f7d35'; ctx.beginPath();
    ctx.ellipse(x + wob, gy - 18 * k, 19 * k, 18 * k, 0, 0, 7); ctx.ellipse(x - 13 * k + wob, gy - 9 * k, 13 * k, 11 * k, 0, 0, 7); ctx.ellipse(x + 13 * k + wob, gy - 10 * k, 13 * k, 11 * k, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#4a9e45'; ctx.beginPath(); ctx.ellipse(x - 5 * k + wob, gy - 27 * k, 9 * k, 5 * k, -0.3, 0, 7); ctx.fill();
    const fl = [[-9, -20, '#ff8a65'], [7, -26, '#ffd54f'], [11, -12, '#f06292'], [-3, -9, '#ffd54f'], [2, -18, '#f06292']];
    for (const [fx, fy, c] of fl) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x + fx * k + wob, gy + fy * k, 2.6, 0, 7); ctx.fill(); }
  }
}
function drawBoulder() {
  const b = ob('boulder');
  const x = b.x - camX; if (x > viewW + 80 || x + b.w < -80) return;
  const p = b.prog, busy = S.team.seqOb === b && (S.team.mood === 'chisel' || S.team.mood === 'work');
  const shake = busy ? Math.sin(S.t * 40) * 1.2 : 0;
  const rubble = (n, spread) => {
    for (let k = 0; k < n; k++) {
      const rx = x - spread / 2 + ((k * 37) % 100) / 100 * (b.w + spread), rs = 5 + (k * 13) % 7;
      ctx.fillStyle = k % 2 ? '#8a8d91' : '#a6a9ad'; ctx.beginPath(); ctx.ellipse(rx, GROUND - rs * 0.45 + 2, rs, rs * 0.7, 0, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.ellipse(rx - rs * 0.3, GROUND - rs * 0.7 + 2, rs * 0.4, rs * 0.25, 0, 0, 7); ctx.fill();
    }
  };
  if (b.done) return; // the rubble is drawn in front of the bush row (drawRubble)
  if (p < 0.55) {
    ctx.fillStyle = '#8a8d91';
    ctx.beginPath(); ctx.ellipse(x + b.w / 2 + shake, GROUND - 48, b.w / 2, 56, 0, Math.PI, 0); ctx.lineTo(x + b.w + shake, GROUND + 4); ctx.lineTo(x + shake, GROUND + 4); ctx.fill();
    ctx.fillStyle = '#a7aaae';
    ctx.beginPath(); ctx.ellipse(x + b.w * 0.38 + shake, GROUND - 70, b.w * 0.22, 18, -0.4, 0, 7); ctx.fill();
    ctx.fillStyle = '#5f8f3a';
    ctx.beginPath(); ctx.ellipse(x + b.w * 0.7 + shake, GROUND - 92, 24, 9, 0.3, 0, 7); ctx.fill();
    const n = p > 0 ? Math.ceil(p / 0.55 * CRACKS.length) : 0;
    ctx.strokeStyle = '#34363a'; ctx.lineWidth = 2.4; ctx.lineJoin = 'round';
    for (let k = 0; k < n; k++) { ctx.beginPath(); CRACKS[k].forEach(([fx, fy], j) => j ? ctx.lineTo(x + fx * b.w + shake, GROUND + fy) : ctx.moveTo(x + fx * b.w + shake, GROUND + fy)); ctx.stroke(); }
    ctx.lineJoin = 'miter';
    if (p === 0) { ctx.strokeStyle = '#6a6d71'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + b.w * 0.6, GROUND - 40); ctx.lineTo(x + b.w * 0.72, GROUND - 22); ctx.lineTo(x + b.w * 0.66, GROUND - 6); ctx.stroke(); }
  } else {
    if (!b.split) { b.split = true; for (let k = 0; k < 26; k++) S.particles.push({ kind: 'confetti', x: b.x + b.w / 2 + (Math.random() - 0.5) * 60, y: GROUND - 50 - Math.random() * 40, vx: (Math.random() - 0.5) * 220, vy: -80 - Math.random() * 120, r: 0, vr: 5, life: 0.9, c: '#9a9da1' }); }
    const q = ease((p - 0.55) / 0.45), sz = lerp(1, 0.32, q);
    rubble(Math.floor(q * 14), 40);
    const chunk = (cx, cy, rx, ry, c) => { ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(cx + shake, cy, rx, ry, 0, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(40,40,44,0.5)'; ctx.lineWidth = 1.5; ctx.stroke(); };
    chunk(x + b.w * 0.24 - 34 * q, GROUND - 40 * sz, 40 * sz, 42 * sz, '#868a8e');
    chunk(x + b.w * 0.78 + 34 * q, GROUND - 38 * sz, 38 * sz, 40 * sz, '#8f9296');
    chunk(x + b.w * 0.5, GROUND - lerp(84, 22, q), 32 * sz, 25 * sz, '#a2a5a9');
  }
}

function drawCliff() {
  const c = ob('cliff');
  const x = c.x - camX; if (x > viewW + 120 || x < -160) return;
  // rocky outcrop: the forest floor ends in a sheer, layered rock face
  ctx.fillStyle = '#7d6a55';
  ctx.beginPath(); ctx.moveTo(x - 70, GROUND + 2); ctx.lineTo(x - 2, GROUND - 2);
  ctx.lineTo(x + 10, GROUND + 22); ctx.lineTo(x + 22, GROUND + 30); ctx.lineTo(x + 34, GROUND + 52); ctx.lineTo(x + 48, GROUND + 64);
  ctx.lineTo(x + c.w + 6, LOW_GROUND + 2); ctx.lineTo(x - 70, LOW_GROUND + 30); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#5a4a3a'; ctx.lineWidth = 2;
  for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x - 60, GROUND + 14 + k * 16); ctx.lineTo(x + 6 + k * 13, GROUND + 14 + k * 16); ctx.stroke(); }
  ctx.fillStyle = '#9a8670';
  ctx.beginPath(); ctx.moveTo(x - 2, GROUND - 2); ctx.lineTo(x + 10, GROUND + 22); ctx.lineTo(x + 2, GROUND + 22); ctx.closePath(); ctx.fill();
  // warning sign appears once the manager has spotted it
  if (c.spotted && c.informed) {
    ctx.fillStyle = '#5a3a1a'; ctx.fillRect(x - 54, GROUND - 34, 3, 34);
    ctx.fillStyle = '#ffcc33'; ctx.beginPath(); ctx.moveTo(x - 52, GROUND - 52); ctx.lineTo(x - 38, GROUND - 30); ctx.lineTo(x - 66, GROUND - 30); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#222'; ctx.font = 'bold 13px sans-serif'; ctx.fillText('!', x - 54, GROUND - 33);
  }
  // rope
  if (c.prog > 0) {
    ctx.fillStyle = '#5a3a1a'; ctx.fillRect(x - 14, GROUND - 16, 5, 18);
    ctx.strokeStyle = '#e0c38a'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.moveTo(x - 12, GROUND - 14);
    ctx.lineTo(lerp(x - 12, x + c.w + 4, c.prog), lerp(GROUND - 14, LOW_GROUND - 4, c.prog)); ctx.stroke();
  }
}

function drawVineThicket() {
  const v = ob('vines');
  const x = v.x - camX; if (x > viewW + 60 || x + v.w < -60) return;
  const r = rng(7);
  const n = 26;
  for (let i = 0; i < n; i++) {
    const vx = x + r() * v.w, top = CANOPY_BOTTOM - 10 + r() * 60, ph = r() * 6;
    const cut = i < Math.floor(v.prog * n);
    const bottom = cut ? top + (GROUND - top) * 0.35 : GROUND + 2;
    ctx.strokeStyle = i % 2 ? '#2f7a2d' : '#3c9440'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(vx, top);
    const sw = Math.sin(S.t * 1.5 + ph) * 4;
    ctx.bezierCurveTo(vx + 14 + sw, top + (bottom - top) * 0.3, vx - 14 - sw, top + (bottom - top) * 0.65, vx + sw, bottom);
    ctx.stroke();
    if (!cut) {
      ctx.fillStyle = '#4fae46';
      for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.ellipse(vx + (k - 1) * 6, top + (bottom - top) * (0.3 + k * 0.25), 5, 2.5, k, 0, 7); ctx.fill(); }
    }
  }
  if (v.prog < 1) { // dense undergrowth at the base
    ctx.fillStyle = 'rgba(40,110,40,0.9)';
    ctx.beginPath(); ctx.ellipse(x + v.w / 2, GROUND - 14, v.w / 2 * (1 - v.prog * 0.8) + 4, 26 * (1 - v.prog * 0.7), 0, Math.PI, 0); ctx.fill();
  }
}

function drawBushes() {
  const cols = ['rgba(52,120,50,0.92)', 'rgba(70,140,60,0.92)', 'rgba(40,100,45,0.92)'];
  for (const b of deco.bushes) {
    const x = b.x - camX; if (x < -60 || x > viewW + 60) continue;
    const gy = groundBase(b.x) + 6;
    ctx.fillStyle = cols[b.c];
    ctx.beginPath();
    ctx.ellipse(x, gy - 8 * b.s, 22 * b.s, 13 * b.s, 0, 0, 7);
    ctx.ellipse(x + 15 * b.s, gy - 4 * b.s, 15 * b.s, 10 * b.s, 0, 0, 7);
    ctx.ellipse(x - 14 * b.s, gy - 3 * b.s, 13 * b.s, 9 * b.s, 0, 0, 7);
    ctx.fill();
  }
}

function drawCanopy() {
  const cols = ['rgba(46,125,50,0.88)', 'rgba(67,160,71,0.86)', 'rgba(30,100,40,0.9)', 'rgba(102,187,106,0.82)'];
  for (const b of deco.blobs) {
    const x = b.x - camX; if (x < -80 || x > viewW + 80) continue;
    ctx.fillStyle = cols[b.c];
    const sw = Math.sin(S.t * 0.8 + b.x) * 2;
    ctx.beginPath(); ctx.ellipse(x + sw, b.y, b.rad, b.rad * 0.62, 0, 0, 7); ctx.fill();
  }
  // leafy highlight along the top edge
  ctx.fillStyle = 'rgba(150,215,120,0.55)';
  for (const b of deco.blobs) {
    const x = b.x - camX; if (x < -80 || x > viewW + 80 || b.y > CANOPY_TOP + 45) continue;
    ctx.beginPath(); ctx.ellipse(x - b.rad * 0.2, b.y - b.rad * 0.3, b.rad * 0.45, b.rad * 0.2, 0, 0, 7); ctx.fill();
  }
}


function ring(x, y, r, col) {
  ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.setLineDash([6, 5]); ctx.lineDashOffset = -S.t * 20;
  ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke(); ctx.restore();
}

function tag(x, y, text, col) {
  ctx.font = 'bold 10px system-ui, sans-serif';
  const w = ctx.measureText(text).width + 10;
  ctx.fillStyle = 'rgba(0,0,0,0.55)'; rr(x - w / 2, y - 9, w, 14, 7); ctx.fill();
  ctx.fillStyle = col; ctx.textAlign = 'center'; ctx.fillText(text, x, y + 1.5); ctx.textAlign = 'left';
}

function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }


function drawBeam() {
  const L = S.leader; if (!L.beam) return;
  const lx = L.x - camX, ly = L.y;
  const creek = L.beam === 'creek';
  const tx = (creek ? (CREEK.x0 + CREEK.x1) / 2 : L.beam === 'goal' ? GOAL_X : START_X) - camX, ty = creek ? GROUND + 26 : L.beam === 'goal' ? PYR_APEX + 6 : CANOPY_TOP + 10;
  const a = Math.min(1, L.beamT) * 0.8;
  if (creek) { // course correction: the beam re-aims at the better route, then on to the pyramid
    ctx.save(); ctx.globalAlpha = a; ring(tx, ty, 26 + Math.sin(S.t * 4) * 3, '#ffd34d'); ctx.restore();
    ctx.save(); ctx.strokeStyle = `rgba(255,211,77,${a})`; ctx.lineWidth = 3; ctx.setLineDash([10, 8]); ctx.lineDashOffset = -S.t * 40;
    ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(tx, ty); ctx.stroke(); ctx.restore();
    const lbl = 'New route: via the creek ➜ 🔺';
    ctx.font = 'bold 13px system-ui, sans-serif'; const lw = ctx.measureText(lbl).width + 28;
    ctx.fillStyle = `rgba(0,0,0,${a * 0.6})`; rr(viewW - lw - 16, 18, lw, 26, 13); ctx.fill();
    ctx.fillStyle = `rgba(255,211,77,${a + 0.2})`; ctx.textAlign = 'center';
    ctx.fillText(lbl, viewW - 16 - lw / 2, 36); ctx.textAlign = 'left';
    return;
  }
  ctx.save(); ctx.strokeStyle = `rgba(255,211,77,${a})`; ctx.lineWidth = 3; ctx.setLineDash([10, 8]); ctx.lineDashOffset = -S.t * 40;
  ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(tx, ty); ctx.stroke(); ctx.restore();
  // if the target is off-screen, show an arrow at the edge
  if (tx > viewW - 10 || tx < 10) {
    const ex = tx > viewW ? viewW - 70 : 70;
    ctx.fillStyle = `rgba(0,0,0,${a * 0.6})`; rr(ex - 58, 18, 116, 26, 13); ctx.fill();
    ctx.fillStyle = `rgba(255,211,77,${a + 0.2})`; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(L.beam === 'goal' ? 'Pyramid  ➜' : '⬅  Start', ex, 36); ctx.textAlign = 'left';
  }
}

function drawPulses() {
  for (const p of S.pulses) {
    const a = agentPos(p.from), b = agentPos(p.to);
    const t = p.t / p.dur;
    const ax = a.x - camX, bx = b.x - camX;
    ctx.save(); ctx.strokeStyle = p.color; ctx.globalAlpha = 0.35; ctx.lineWidth = 2; ctx.setLineDash([3, 6]);
    ctx.beginPath(); ctx.moveTo(ax, a.y); ctx.lineTo(bx, b.y); ctx.stroke(); ctx.restore();
    for (let k = 0; k < 3; k++) {
      const tt = t - k * 0.08; if (tt < 0) continue;
      const x = lerp(ax, bx, tt), y = lerp(a.y, b.y, tt);
      ctx.strokeStyle = p.color; ctx.globalAlpha = 1 - k * 0.3; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(x, y, 7 + k * 5 + Math.sin(S.t * 10) * 2, 0, 7); ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
}

function drawBubbles() {
  const cols = { leader: ['#fff7d6', '#b08a00'], manager: ['#f3e8ff', '#7b3fb0'], team: ['#e3f6ff', '#1f6f9f'],
    visitor: S.mgr.meeting ? [S.mgr.meeting.def.belly, S.mgr.meeting.def.body] : ['#eee', '#777'] };
  ctx.font = '600 13px system-ui, sans-serif';
  for (const b of S.bubbles) {
    const p = agentPos(b.who);
    if (p.x - camX < -30 || p.x - camX > viewW + 30) continue; // speaker is off-screen
    const a = Math.min(1, b.t * 4, (b.dur - b.t) * 3);
    const w = ctx.measureText(b.text).width + 20, h = 26;
    const px = p.x - camX;
    let x, y;
    ctx.globalAlpha = a;
    ctx.fillStyle = cols[b.who][0]; ctx.strokeStyle = cols[b.who][1]; ctx.lineWidth = 2;
    if (b.who === 'leader' && S.leader.meeting) {
      // In a meeting the visiting eagles' priority cards sit beside the leader, so its bubble goes underneath.
      x = clamp(px - w / 2, 6, viewW - w - 6); y = p.y + 84; // below the visitors' name tags too
      rr(x, y, w, h, 10); ctx.fill(); ctx.stroke();
      const tx = clamp(px, x + 12, x + w - 12);
      ctx.beginPath(); ctx.moveTo(tx - 6, y + 1); ctx.lineTo(tx, y - 9); ctx.lineTo(tx + 6, y + 1); ctx.fill();
    } else if (b.who === 'leader') {
      // The eagle flies near the top of the sky, so its bubble sits beside it instead of above.
      const right = px + 58 + w < viewW - 6;
      x = right ? px + 58 : px - 58 - w; y = clamp(p.y - h / 2 - 6, 4, H - h);
      rr(x, y, w, h, 10); ctx.fill(); ctx.stroke();
      const ex = right ? x + 1 : x + w - 1, dir = right ? -1 : 1;
      ctx.beginPath(); ctx.moveTo(ex, y + h / 2 - 6); ctx.lineTo(ex + dir * 10, y + h / 2 + 2); ctx.lineTo(ex, y + h / 2 + 6); ctx.fill();
    } else {
      x = clamp(px - w / 2, 6, viewW - w - 6);
      y = p.y - (b.who === 'team' ? 44 : 58) - h;
      rr(x, y, w, h, 10); ctx.fill(); ctx.stroke();
      const tx = clamp(px, x + 12, x + w - 12);
      ctx.beginPath(); ctx.moveTo(tx - 6, y + h - 1); ctx.lineTo(tx, y + h + 9); ctx.lineTo(tx + 6, y + h - 1); ctx.fill();
    }
    ctx.fillStyle = '#222'; ctx.fillText(b.text, x + 10, y + 17.5);
    ctx.globalAlpha = 1;
  }
}

function drawFog() {
  const v = settings.view; if (v === 'all') return;
  const W = canvas.width, Hh = canvas.height;
  if (fog.width !== W || fog.height !== Hh) { fog.width = W; fog.height = Hh; }
  fctx.setTransform(1, 0, 0, 1, 0, 0);
  fctx.globalCompositeOperation = 'source-over';
  fctx.clearRect(0, 0, W, Hh);
  fctx.setTransform(scale, 0, 0, scale, 0, 0);
  const color = { leader: 'rgba(24,64,32,0.93)', manager: 'rgba(205,220,210,0.93)', team: 'rgba(10,22,14,0.95)' }[v];
  fctx.fillStyle = color; fctx.fillRect(0, 0, viewW, H);
  fctx.globalCompositeOperation = 'destination-out';
  if (v === 'leader') {
    const g = fctx.createLinearGradient(0, CANOPY_BOTTOM - 70, 0, CANOPY_BOTTOM + 10);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    fctx.fillStyle = g; fctx.fillRect(0, 0, viewW, CANOPY_BOTTOM + 10);
  } else if (v === 'manager') {
    const cx = S.mgr.x - camX + 120, cy = 400;
    fctx.save(); fctx.translate(cx, cy); fctx.scale(2.3, 1);
    const g = fctx.createRadialGradient(0, 0, 60, 0, 0, 230);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(0.75, 'rgba(0,0,0,0.95)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    fctx.fillStyle = g; fctx.beginPath(); fctx.arc(0, 0, 230, 0, 7); fctx.fill(); fctx.restore();
  } else if (v === 'team') {
    const p = agentPos('team');
    const g = fctx.createRadialGradient(p.x - camX, p.y + 10, 40, p.x - camX, p.y + 10, 190);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(0.6, 'rgba(0,0,0,0.9)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    fctx.fillStyle = g; fctx.beginPath(); fctx.arc(p.x - camX, p.y + 10, 190, 0, 7); fctx.fill();
  }
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(fog, 0, 0); ctx.restore();
}

function drawViewBanner() {
  const v = settings.view; if (v === 'all') return;
  const text = {
    leader: '🦅 LEADER VIEW: sees the start and the goal, but not the ground',
    manager: '🦉 MANAGER VIEW: sees the obstacles ahead, but not the far-off goal',
    team: '🐨 TEAM VIEW: the koalas see only what\'s right in front of them',
  }[v];
  ctx.font = 'bold 14px system-ui, sans-serif';
  const w = ctx.measureText(text).width + 24;
  ctx.fillStyle = 'rgba(0,0,0,0.6)'; rr(12, H - 40, w, 28, 14); ctx.fill();
  ctx.fillStyle = '#fff'; ctx.fillText(text, 24, H - 21);
}

function frame(ts) {
  raf = requestAnimationFrame(frame);
  const dt = Math.min(0.05, (ts - (lastT || ts)) / 1000);
  lastT = ts;
  if (settings.playing) {
    const sdt = dt * settings.speed;
    // sub-step for stability at high speeds
    const n = Math.ceil(sdt / 0.02) || 1;
    for (let i = 0; i < n; i++) { update(sdt / n); updateCamera(sdt / n); }
  }
  render();
}


function resize() {
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(320, Math.round(rect.width * dpr));
  canvas.height = Math.max(160, Math.round(rect.height * dpr));
  scale = canvas.height / H;
  viewW = canvas.width / scale;
}


function onKey(e) {
  if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
  if (e.code === 'Space') { e.preventDefault(); settings.playing = !settings.playing; call('OnPlayState', settings.playing); }
  else if (e.key === 'r' || e.key === 'R') { reset(); call('OnRestarted'); }
  else if (['1', '2', '3', '4'].includes(e.key)) { settings.view = ['all', 'leader', 'manager', 'team'][+e.key - 1]; call('OnViewChanged', settings.view); }
}


// ---------- drawing (new in v2) ----------
function drawPyramid() {
  const x = GOAL_X - camX;
  if (x < -PYR_HALF - 20 || x > viewW + PYR_HALF + 20) return;
  const by = groundBase(GOAL_X) + 2;
  ctx.fillStyle = '#d9b066';
  ctx.beginPath(); ctx.moveTo(x - PYR_HALF, by); ctx.lineTo(x, PYR_APEX); ctx.lineTo(x + PYR_HALF, by); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#b98c45';
  ctx.beginPath(); ctx.moveTo(x, PYR_APEX); ctx.lineTo(x + PYR_HALF, by); ctx.lineTo(x + 30, by); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(120,85,40,0.45)'; ctx.lineWidth = 1.2;
  for (let y = PYR_APEX + 26; y < by; y += 22) {
    const half = PYR_HALF * (y - PYR_APEX) / (by - PYR_APEX);
    ctx.beginPath(); ctx.moveTo(x - half, y); ctx.lineTo(x + half, y); ctx.stroke();
  }
  ctx.fillStyle = '#4a3418';
  ctx.beginPath(); ctx.moveTo(x - 16, by); ctx.lineTo(x - 16, by - 30); ctx.arc(x, by - 30, 16, Math.PI, 0); ctx.lineTo(x + 16, by); ctx.fill();
  ctx.fillStyle = '#ffe58a';
  ctx.beginPath(); ctx.moveTo(x, PYR_APEX); ctx.lineTo(x - 11, PYR_APEX + 18); ctx.lineTo(x + 11, PYR_APEX + 18); ctx.closePath(); ctx.fill();
}

function drawPathBushes() {
  for (const b of S.pathBushes) {
    if (b.lantana) continue;
    const x = b.x - camX; if (x < -40 || x > viewW + 40) continue;
    const gy = groundBase(b.x) + 3;
    if (b.cut) {
      ctx.fillStyle = '#6d4c2f'; ctx.fillRect(x - 5, gy - 8, 4, 8); ctx.fillRect(x + 2, gy - 10, 4, 10);
      ctx.fillStyle = 'rgba(76,175,80,0.7)';
      ctx.beginPath(); ctx.ellipse(x - 9, gy - 1, 4, 1.6, 0.3, 0, 7); ctx.ellipse(x + 10, gy - 1, 4, 1.6, -0.4, 0, 7); ctx.fill();
      continue;
    }
    const k = 1.35 * b.s * (0.35 + 0.65 * b.hp);
    const wob = b.hp < 1 ? Math.sin(S.t * 40) * 1.5 : 0;
    ctx.fillStyle = '#3d9a3f';
    ctx.beginPath();
    ctx.ellipse(x + wob, gy - 14 * k, 16 * k, 14 * k, 0, 0, 7);
    ctx.ellipse(x - 10 * k + wob, gy - 7 * k, 11 * k, 9 * k, 0, 0, 7);
    ctx.ellipse(x + 11 * k + wob, gy - 8 * k, 11 * k, 9 * k, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = '#5cbf55';
    ctx.beginPath(); ctx.ellipse(x - 4 * k + wob, gy - 20 * k, 7 * k, 4 * k, -0.3, 0, 7); ctx.fill();
    ctx.fillStyle = '#d84343';
    ctx.beginPath(); ctx.arc(x + 6 * k, gy - 12 * k, 1.8, 0, 7); ctx.arc(x - 7 * k, gy - 9 * k, 1.8, 0, 7); ctx.fill();
  }
}

function drawBog(front) {
  const b = ob('bog'); const x = b.x - camX;
  if (x > viewW + 30 || x + b.w < -30) return;
  if (!front) {
    ctx.fillStyle = '#4b5a2a';
    ctx.beginPath(); ctx.ellipse(x + b.w / 2, GROUND + 4, b.w / 2 + 8, 14, 0, 0, 7); ctx.fill();
    ctx.fillRect(x - 4, GROUND + 2, b.w + 8, 40);
    // bubbles popping
    ctx.strokeStyle = 'rgba(190,200,140,0.8)'; ctx.lineWidth = 1.5;
    for (let i = 0; i < 5; i++) {
      const ph = (S.t * 0.7 + i * 0.37) % 1;
      ctx.beginPath(); ctx.arc(x + 20 + i * (b.w - 40) / 4, GROUND + 4 - ph * 4, 2 + ph * 4, 0, 7); ctx.stroke();
    }
    // reeds
    ctx.strokeStyle = '#6f8f3a'; ctx.lineWidth = 2;
    for (const rx of [x - 6, x + 4, x + b.w - 4, x + b.w + 6]) {
      ctx.beginPath(); ctx.moveTo(rx, GROUND + 6); ctx.quadraticCurveTo(rx + 3, GROUND - 14, rx + 1 + Math.sin(S.t + rx) * 2, GROUND - 30); ctx.stroke();
      ctx.fillStyle = '#7a4a2a'; ctx.beginPath(); ctx.ellipse(rx + 1, GROUND - 26, 2.4, 6, 0, 0, 7); ctx.fill();
    }
    // stepping stones
    const n = Math.floor(b.prog * 6 + 0.0001);
    for (let k = 0; k < n; k++) {
      const sx = x + (k + 0.5) * b.w / 6;
      ctx.fillStyle = '#8d8d8d'; ctx.beginPath(); ctx.ellipse(sx, GROUND + 1, 14, 5.5, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#b0b0b0'; ctx.beginPath(); ctx.ellipse(sx - 2, GROUND - 1, 8, 2.5, 0, 0, 7); ctx.fill();
    }
  } else {
    ctx.fillStyle = 'rgba(70,86,38,0.9)';
    ctx.fillRect(x - 2, GROUND + 7, b.w + 4, 36);
    if (S.team.m0 > 5 && S.team.seqOb === b) {
      const sx = S.team.x + S.team.m0 - camX;
      ctx.fillStyle = 'rgba(150,160,90,0.9)';
      for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(sx + Math.sin(S.t * 6 + i) * 12, GROUND + 8 - Math.abs(Math.cos(S.t * 5 + i)) * 6, 2.5, 0, 7); ctx.fill(); }
    }
  }
}

function drawLog() {
  const o = ob('log'); const x = o.x - camX;
  if (x > viewW + 40 || x + o.w < -40) return;
  const top = GROUND - 76, hgt = 78, cy = top + hgt / 2;
  const g = ctx.createLinearGradient(0, top, 0, GROUND);
  g.addColorStop(0, '#8a5a34'); g.addColorStop(0.5, '#6d4426'); g.addColorStop(1, '#4e2f19');
  ctx.fillStyle = g; ctx.fillRect(x, top, o.w, hgt);
  ctx.strokeStyle = 'rgba(40,22,10,0.5)'; ctx.lineWidth = 2;
  for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.moveTo(x + 10, top + 12 + k * 14); ctx.bezierCurveTo(x + o.w * 0.3, top + 8 + k * 14, x + o.w * 0.6, top + 18 + k * 14, x + o.w - 6, top + 12 + k * 14); ctx.stroke(); }
  // moss + mushrooms on top
  ctx.fillStyle = '#5f9a3a'; ctx.beginPath(); ctx.ellipse(x + o.w * 0.45, top + 2, o.w * 0.35, 6, 0, 0, 7); ctx.fill();
  for (const mx of [0.25, 0.7]) {
    ctx.fillStyle = '#f4e3c0'; ctx.fillRect(x + o.w * mx - 1.5, top - 8, 3, 8);
    ctx.fillStyle = '#d84a3a'; ctx.beginPath(); ctx.arc(x + o.w * mx, top - 8, 6, Math.PI, 0); ctx.fill();
  }
  // right end (solid rings)
  ctx.fillStyle = '#c99a62'; ctx.beginPath(); ctx.ellipse(x + o.w, cy, 14, hgt / 2, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#2a1a0c'; ctx.beginPath(); ctx.ellipse(x + o.w, cy + 4, 9, hgt / 2 - 10, 0, 0, 7); ctx.fill();
  // left end: the hollow entrance
  ctx.fillStyle = '#c99a62'; ctx.beginPath(); ctx.ellipse(x, cy, 14, hgt / 2, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#1e1208'; ctx.beginPath(); ctx.ellipse(x, cy + 4, 9.5, hgt / 2 - 9, 0, 0, 7); ctx.fill();
  if (o.prog < 1) { // cobwebs
    ctx.strokeStyle = `rgba(255,255,255,${0.75 * (1 - o.prog)})`; ctx.lineWidth = 1;
    for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; ctx.beginPath(); ctx.moveTo(x, cy + 4); ctx.lineTo(x + Math.cos(a) * 9, cy + 4 + Math.sin(a) * (hgt / 2 - 10)); ctx.stroke(); }
    for (const rr2 of [0.35, 0.7]) { ctx.beginPath(); ctx.ellipse(x, cy + 4, 9 * rr2, (hgt / 2 - 10) * rr2, 0, 0, 7); ctx.stroke(); }
  }
}

function drawBees(front) {
  const o = ob('bees'); const x = o.x - camX;
  if (x > viewW + 80 || x + o.w < -80) return;
  const by = groundBase(o.x) - 175, cx = x + o.w / 2;
  if (!front) {
  ctx.strokeStyle = '#5b3e2b'; ctx.lineWidth = 7; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x - 70, by - 12); ctx.quadraticCurveTo(cx, by + 6, x + o.w + 60, by - 4); ctx.stroke(); ctx.lineCap = 'butt';
  ctx.fillStyle = '#3f8f3a';
  for (const lx of [-50, -10, 70, 120]) { ctx.beginPath(); ctx.ellipse(x + lx, by - 10, 10, 4, 0.4, 0, 7); ctx.fill(); }
  // nest
  ctx.strokeStyle = '#5b3e2b'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx, by); ctx.lineTo(cx, by + 8); ctx.stroke();
  ctx.fillStyle = '#d9a441'; ctx.beginPath(); ctx.ellipse(cx, by + 30, 17, 23, 0, 0, 7); ctx.fill();
  ctx.strokeStyle = '#a8752a'; ctx.lineWidth = 2;
  for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.ellipse(cx, by + 30 + k * 8, 16 - Math.abs(k) * 2.5, 2, 0, 0, Math.PI); ctx.stroke(); }
  ctx.fillStyle = '#3a2a10'; ctx.beginPath(); ctx.arc(cx + 2, by + 38, 3.5, 0, 7); ctx.fill();
  }
  if (front) {
  // bees: orbit lazily, or chase the koalas when angry
  const tp = agentPos('team'), k = clamp(o.angry / 2.5, 0, 1);
  for (let i = 0; i < 9; i++) {
    const a = S.t * (1.5 + i * 0.15) + i * 0.7;
    let bx = cx + Math.cos(a) * (26 + i * 2), byy = by + 30 + Math.sin(a * 1.3) * (18 + i);
    if (k > 0) { bx = lerp(bx, tp.x - camX + Math.cos(a * 3) * 34, k); byy = lerp(byy, tp.y + 30 + Math.sin(a * 3) * 26, k); }
    ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.ellipse(bx - 1, byy - 4.5, 4, 2.2, -0.5 + Math.sin(S.t * 40 + i) * 0.4, 0, 7); ctx.fill();
    ctx.fillStyle = '#ffcc1a'; ctx.beginPath(); ctx.ellipse(bx, byy, 5, 3.5, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#222'; ctx.fillRect(bx - 1, byy - 3.4, 1.8, 6.8); ctx.fillRect(bx + 2.2, byy - 2.6, 1.4, 5.2);
  }
  if (!o.angry && !o.done) { ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.font = 'bold 11px sans-serif'; ctx.fillText('z z', cx + 20, by + 8 - (S.t * 6 % 6)); }
  }
}
function drawWall() {
  const w = ob('wall'); const x = w.x - camX;
  if (x > viewW + 120 || x < -160) return;
  ctx.fillStyle = '#857261';
  ctx.beginPath(); ctx.moveTo(x - 4, LOW_GROUND + 4); ctx.lineTo(x + 4, LOW_GROUND - 22); ctx.lineTo(x + 14, LOW_GROUND - 36); ctx.lineTo(x + 22, GROUND + 26);
  ctx.lineTo(x + 34, GROUND + 12); ctx.lineTo(x + w.w + 2, GROUND - 2); ctx.lineTo(x + w.w + 80, GROUND + 2); ctx.lineTo(x + w.w + 80, LOW_GROUND + 30); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#64544a'; ctx.lineWidth = 2;
  for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x + 8 + k * 9, LOW_GROUND - 10 - k * 18); ctx.lineTo(x + w.w + 70, LOW_GROUND - 14 - k * 18); ctx.stroke(); }
  ctx.fillStyle = '#5f9a3a'; ctx.beginPath(); ctx.ellipse(x + w.w + 30, GROUND, 40, 5, 0, 0, 7); ctx.fill();
  if (w.prog > 0) {
    const bx = x - 16, byy = LOW_GROUND - 2, tx = x + w.w + 4, ty = GROUND - 8;
    const L = Math.hypot(tx - bx, byy - ty), th = Math.atan2(byy - ty, tx - bx) * w.prog;
    const ex = bx + L * Math.cos(th), ey = byy - L * Math.sin(th);
    const nx = -Math.sin(th) * 5, ny = -Math.cos(th) * 5;
    ctx.strokeStyle = '#c08a4a'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(bx + nx, byy + ny); ctx.lineTo(ex + nx, ey + ny); ctx.moveTo(bx - nx, byy - ny); ctx.lineTo(ex - nx, ey - ny); ctx.stroke();
    ctx.lineWidth = 2;
    for (let s = 0.1; s < 1; s += 0.12) { const px = lerp(bx, ex, s), py = lerp(byy, ey, s); ctx.beginPath(); ctx.moveTo(px + nx, py + ny); ctx.lineTo(px - nx, py - ny); ctx.stroke(); }
  }
}

function drawLeader() {
  const L = S.leader, x = L.x + L.ox - camX, y = L.y + L.oy;
  const flap = Math.sin(S.t * (L.dist ? 9 : 5)) * 14;
  ctx.save(); ctx.translate(x, y); ctx.rotate(L.rot);
  if (S.selected === 'leader') ring(0, 0, 40, '#ffd34d');
  ctx.fillStyle = '#6b4423';
  ctx.beginPath(); ctx.moveTo(-4, 0); ctx.quadraticCurveTo(-26, -10 - flap, -52, -4 - flap * 1.4); ctx.quadraticCurveTo(-30, 4, -4, 6); ctx.fill();
  ctx.beginPath(); ctx.moveTo(4, 0); ctx.quadraticCurveTo(26, -10 - flap, 52, -4 - flap * 1.4); ctx.quadraticCurveTo(30, 4, 4, 6); ctx.fill();
  ctx.fillStyle = '#7a4f2a'; ctx.beginPath(); ctx.ellipse(0, 2, 10, 18, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#5a3a1e'; ctx.beginPath(); ctx.moveTo(-7, 16); ctx.lineTo(0, 28); ctx.lineTo(7, 16); ctx.fill();
  ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(0, -14, 8, 0, 7); ctx.fill();
  ctx.fillStyle = '#f2b233'; ctx.beginPath(); ctx.moveTo(-3, -11); ctx.lineTo(0, -4); ctx.lineTo(3, -11); ctx.fill();
  ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(-3, -16, 1.4, 0, 7); ctx.arc(3, -16, 1.4, 0, 7); ctx.fill();
  ctx.restore();
  if (L.dist) drawLeaderFX(L, x, y);
  tag(x, y - 34, 'LEADER', '#ffd34d');
}
function drawLeaderFX(L, x, y) {
  const d = L.dist, t = S.t, fade = d.phase === 'distract' ? 1 : Math.max(0, 1 - d.t / 0.8);
  if (fade <= 0) return;
  ctx.save(); ctx.globalAlpha = fade;
  if (d.def.kind === 'magpie') {
    const mx = x + Math.cos(t * 4.5) * 58, my = y - 14 + Math.sin(t * 9) * 22, dir = -Math.sin(t * 4.5) >= 0 ? 1 : -1;
    ctx.save(); ctx.translate(mx, my); ctx.scale(dir, 1);
    ctx.fillStyle = '#111'; ctx.beginPath(); ctx.ellipse(0, 0, 11, 5.5, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(9, -3, 4.5, 0, 7); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(-2, -2, 6, 2.4, -0.2, 0, 7); ctx.fill(); ctx.fillRect(4, -6, 3, 4);
    ctx.fillStyle = '#9aa'; ctx.beginPath(); ctx.moveTo(13, -4); ctx.lineTo(19, -2); ctx.lineTo(13, -1); ctx.fill();
    ctx.fillStyle = '#111'; ctx.beginPath(); ctx.moveTo(-3, -2); ctx.lineTo(-10, -12 - Math.sin(t * 20) * 6); ctx.lineTo(4, -3); ctx.fill();
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(x, y - 6, 62, t * 4.5 - 0.6, t * 4.5 - 0.1); ctx.stroke();
  } else if (d.def.kind === 'email') {
    for (let k = 0; k < 4; k++) {
      const a = t * 2.4 + k * Math.PI / 2, ex = x + Math.cos(a) * 52, ey = y - 6 + Math.sin(a) * 26;
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#888'; ctx.lineWidth = 1;
      ctx.fillRect(ex - 9, ey - 6, 18, 12); ctx.strokeRect(ex - 9, ey - 6, 18, 12);
      ctx.beginPath(); ctx.moveTo(ex - 9, ey - 6); ctx.lineTo(ex, ey + 1); ctx.lineTo(ex + 9, ey - 6); ctx.stroke();
    }
    ctx.fillStyle = '#e53935'; ctx.beginPath(); ctx.arc(x + 20, y - 26, 9, 0, 7); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('47', x + 20, y - 22.5); ctx.textAlign = 'left';
  } else if (d.def.kind === 'storm') {
    ctx.fillStyle = 'rgba(70,74,84,0.92)';
    ctx.beginPath(); ctx.ellipse(x + 40, y - 30, 50, 15, 0, 0, 7); ctx.ellipse(x + 10, y - 38, 30, 14, 0, 0, 7); ctx.ellipse(x + 70, y - 38, 28, 12, 0, 0, 7); ctx.fill();
    if ((t * 1.7) % 1 < 0.15) {
      ctx.strokeStyle = '#ffeb3b'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(x + 46, y - 18); ctx.lineTo(x + 38, y - 4); ctx.lineTo(x + 48, y - 2); ctx.lineTo(x + 36, y + 16); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 2;
    for (let k = 0; k < 6; k++) {
      const wx = x + 140 - ((t * 320 + k * 57) % 280), wy = y - 26 + k * 11;
      ctx.beginPath(); ctx.moveTo(wx, wy); ctx.quadraticCurveTo(wx - 20, wy - 5, wx - 40, wy); ctx.stroke();
    }
  }
  ctx.restore();
}

function drawManager() {
  const M = S.mgr, x = M.x + M.ox - camX, y = M.y + M.oy;
  const distracted = M.dist && M.dist.phase === 'distract';
  ctx.fillStyle = M.alert > 0 ? 'rgba(255,140,90,0.16)' : (distracted || M.task ? 'rgba(255,255,200,0.03)' : 'rgba(255,255,200,0.10)');
  ctx.beginPath(); ctx.moveTo(x + 10, y + 6); ctx.lineTo(x + 250, GROUND - 120); ctx.lineTo(x + 230, GROUND + 6); ctx.lineTo(x + 40, GROUND + 6); ctx.closePath(); ctx.fill();
  if (M.focusT > 0) { // refocus: re-locks onto the team
    const tp = agentPos('team');
    ctx.save(); ctx.globalAlpha = Math.min(1, M.focusT); ctx.strokeStyle = '#7dff9a'; ctx.lineWidth = 2; ctx.setLineDash([6, 6]);
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(tp.x - camX, tp.y); ctx.stroke(); ctx.restore();
    ring(x, y, 30 + (2 - M.focusT) * 8, 'rgba(125,255,154,0.8)');
  }
  const flap = Math.sin(S.t * 12) * 8;
  ctx.save(); ctx.translate(x, y); ctx.rotate(M.rot);
  if (S.selected === 'manager') ring(0, 0, 36, '#c792ff');
  ctx.fillStyle = '#7b5a8c';
  ctx.beginPath(); ctx.moveTo(-10, 0); ctx.quadraticCurveTo(-28, -8 - flap, -36, 4 - flap); ctx.quadraticCurveTo(-24, 10, -10, 10); ctx.fill();
  ctx.beginPath(); ctx.moveTo(10, 0); ctx.quadraticCurveTo(28, -8 - flap, 36, 4 - flap); ctx.quadraticCurveTo(24, 10, 10, 10); ctx.fill();
  ctx.fillStyle = '#9b74ad'; ctx.beginPath(); ctx.ellipse(0, 2, 15, 18, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#e8d8c0'; ctx.beginPath(); ctx.ellipse(0, 8, 9, 10, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#7b5a8c'; ctx.beginPath(); ctx.moveTo(-13, -12); ctx.lineTo(-10, -22); ctx.lineTo(-4, -14); ctx.fill();
  ctx.beginPath(); ctx.moveTo(13, -12); ctx.lineTo(10, -22); ctx.lineTo(4, -14); ctx.fill();
  ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-6, -6, 6, 0, 7); ctx.arc(6, -6, 6, 0, 7); ctx.fill();
  const look = distracted ? -1.5 : 1.5;
  ctx.fillStyle = '#ffb000'; ctx.beginPath(); ctx.arc(-6 + look, -6, 3.4, 0, 7); ctx.arc(6 + look, -6, 3.4, 0, 7); ctx.fill();
  ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(-6 + look * 1.3, -6, 1.6, 0, 7); ctx.arc(6 + look * 1.3, -6, 1.6, 0, 7); ctx.fill();
  ctx.fillStyle = '#e8a33a'; ctx.beginPath(); ctx.moveTo(-2, 0); ctx.lineTo(0, 5); ctx.lineTo(2, 0); ctx.fill();
  ctx.strokeStyle = '#333'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(12, -14); ctx.lineTo(18, -26); ctx.stroke();
  ctx.fillStyle = settings.comms ? '#5dff8a' : '#ff5d5d'; ctx.beginPath(); ctx.arc(18, -27, 2.6, 0, 7); ctx.fill();
  ctx.restore();
  if (M.dist) drawManagerFX(M, x, y);
  if (M.alert > 0) { ctx.fillStyle = '#ff7043'; ctx.font = 'bold 22px sans-serif'; ctx.fillText('!', x - 4, y - 30); }
  tag(x, y - 42, 'MANAGER', '#c792ff');
}
function drawOwlShape(x, y, body, wing, belly, flapSpeed) {
  const flap = Math.sin(S.t * flapSpeed) * 8;
  ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = wing;
  ctx.beginPath(); ctx.moveTo(-10, 0); ctx.quadraticCurveTo(-28, -8 - flap, -36, 4 - flap); ctx.quadraticCurveTo(-24, 10, -10, 10); ctx.fill();
  ctx.beginPath(); ctx.moveTo(10, 0); ctx.quadraticCurveTo(28, -8 - flap, 36, 4 - flap); ctx.quadraticCurveTo(24, 10, 10, 10); ctx.fill();
  ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(0, 2, 15, 18, 0, 0, 7); ctx.fill();
  ctx.fillStyle = belly; ctx.beginPath(); ctx.ellipse(0, 8, 9, 10, 0, 0, 7); ctx.fill();
  ctx.fillStyle = wing; ctx.beginPath(); ctx.moveTo(-13, -12); ctx.lineTo(-10, -22); ctx.lineTo(-4, -14); ctx.fill();
  ctx.beginPath(); ctx.moveTo(13, -12); ctx.lineTo(10, -22); ctx.lineTo(4, -14); ctx.fill();
  ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-6, -6, 6, 0, 7); ctx.arc(6, -6, 6, 0, 7); ctx.fill();
  ctx.fillStyle = '#ffb000'; ctx.beginPath(); ctx.arc(-7.5, -6, 3.4, 0, 7); ctx.arc(4.5, -6, 3.4, 0, 7); ctx.fill();
  ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(-8, -6, 1.6, 0, 7); ctx.arc(4, -6, 1.6, 0, 7); ctx.fill();
  ctx.fillStyle = '#e8a33a'; ctx.beginPath(); ctx.moveTo(-2, 0); ctx.lineTo(0, 5); ctx.lineTo(2, 0); ctx.fill();
  ctx.restore();
}
// v4: the visiting owl at a manager meeting, with a dashed "sync" link to the Manager while they talk.
function drawMgrMeeting() {
  const M = S.mgr.meeting; if (!M) return;
  const v = mgrVisitorPos(), x = v.x - camX, y = v.y, d = M.def;
  if (x < -80 || x > viewW + 80) return;
  if (M.phase === 'talk') {
    const mx = S.mgr.x + S.mgr.ox - camX, my = S.mgr.y + S.mgr.oy;
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 2; ctx.setLineDash([5, 5]); ctx.lineDashOffset = -S.t * 18;
    ctx.beginPath(); ctx.moveTo(mx + 24, my + 6); ctx.lineTo(x - 24, y); ctx.stroke(); ctx.restore();
    ctx.font = '16px sans-serif'; ctx.fillText('🤝', (mx + x) / 2 - 9, (my + y) / 2 + 6);
  }
  drawOwlShape(x, y, d.body, d.wing, d.belly, M.phase === 'talk' ? 8 : 14);
  tag(x, y + 34, d.label, d.belly);
}
function drawManagerFX(M, x, y) {
  const d = M.dist, t = S.t, fade = d.phase === 'distract' ? 1 : Math.max(0, 1 - d.t / 0.8);
  if (fade <= 0) return;
  ctx.save(); ctx.globalAlpha = fade;
  if (d.def.kind === 'meeting') {
    for (let k = 0; k < 3; k++) {
      const cx = x + 34 + k * 20, cy = y - 18 + Math.sin(t * 4 + k) * 6 - k * 8;
      ctx.fillStyle = '#fff'; ctx.fillRect(cx - 8, cy - 8, 16, 16);
      ctx.fillStyle = '#e53935'; ctx.fillRect(cx - 8, cy - 8, 16, 5);
      ctx.fillStyle = '#333'; ctx.font = 'bold 8px sans-serif'; ctx.fillText('9:00', cx - 8, cy + 6);
    }
  } else if (d.def.kind === 'mosquito') {
    ctx.fillStyle = '#222';
    for (let k = 0; k < 14; k++) {
      const mx = x + Math.sin(t * 17 + k * 1.3) * 30, my = y + Math.cos(t * 13 + k * 2.1) * 24;
      ctx.beginPath(); ctx.arc(mx, my, 1.7, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(mx - 3, my - 2); ctx.lineTo(mx + 3, my - 2); ctx.stroke();
    }
  } else if (d.def.kind === 'branch') {
    ctx.strokeStyle = '#5b3e2b'; ctx.lineWidth = 6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x - 70, y - 40); ctx.quadraticCurveTo(x - 10, y - 10, x + 40, y + 26); ctx.stroke(); ctx.lineCap = 'butt';
    ctx.fillStyle = '#3f8f3a';
    for (const k of [0.2, 0.45, 0.75]) { ctx.beginPath(); ctx.ellipse(lerp(x - 70, x + 40, k), lerp(y - 40, y + 26, k) - 6, 9, 4, 0.5, 0, 7); ctx.fill(); }
    ctx.strokeStyle = '#2f7a2d'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(x, y + 2, 20, 14, Math.sin(t * 6) * 0.4, 0, 7); ctx.stroke();
  }
  ctx.restore();
}

// v4: gathering materials. Each koala heads off the path into the bush, picks something up and carries it back.
const GATHER_SPOTS = [[-46, -30], [-150, 24], [-214, -28], [-92, 22]]; // [dx from the front koala, depth lane]
function gatherPose(i, p, g) {
  const home = -i * MEMBER_GAP, [sx, sl] = GATHER_SPOTS[i];
  const tx = sx * (g.lost ? 1.35 : 1), tl = sl;
  const q = clamp((p - i * 0.05) / 0.82, 0, 1);
  let x, lane, flip, carry = false, crouch = 0, moving = true;
  if (q < 0.3) { const e = ease(q / 0.3); x = lerp(home, tx, e); lane = tl * e; flip = tx < home; moving = q > 0; }
  else if (q < 0.4) { x = tx; lane = tl; flip = tx < home; crouch = Math.sin((q - 0.3) / 0.1 * Math.PI) * 7; moving = false; }
  else if (q < 0.94) { const e = (q - 0.4) / 0.54; x = lerp(tx, home, e < 0.5 ? 2 * e * e * 0 + e : e); lane = tl * (1 - e); flip = !(tx < home); carry = true; }
  else { x = home; lane = 0; flip = false; moving = false; }
  if (g.lost) x += Math.sin(S.t * 2.2 + i * 2) * 16 * Math.sin(Math.PI * q); // wandering, not sure where to look
  return { x, lane, flip, carry, crouch, moving, tx, tl, picked: q >= 0.36, delivered: q >= 0.94 };
}
// Around the boulder: two at the left face, two round the right side (facing back), so the rock stays visible.
const ROCK_FORM = [[8, 0, false], [-14, 28, false], [170, 0, true], [196, 26, true]];
function drawItem(kind, x, y, s) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  if (kind === 'stones') {
    ctx.fillStyle = '#8f9397'; ctx.beginPath(); ctx.ellipse(0, -4, 9, 5.5, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#b4b7bb'; ctx.beginPath(); ctx.ellipse(-2, -6, 4, 2, 0, 0, 7); ctx.fill();
  } else if (kind === 'logs') {
    ctx.fillStyle = '#7a4f2a'; rr(-15, -9, 30, 9, 4); ctx.fill();
    ctx.fillStyle = '#d9b27c'; ctx.beginPath(); ctx.ellipse(15, -4.5, 3, 4.5, 0, 0, 7); ctx.fill();
    ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-10, -6); ctx.lineTo(6, -6); ctx.stroke();
  } else if (kind === 'planks') {
    ctx.fillStyle = '#c99a5b'; ctx.strokeStyle = '#6b4a22'; ctx.lineWidth = 1; ctx.fillRect(-14, -6, 28, 5); ctx.strokeRect(-14, -6, 28, 5);
  } else if (kind === 'vines') {
    ctx.strokeStyle = '#3f8f3a'; ctx.lineWidth = 2.6; ctx.beginPath();
    for (let k = 0; k <= 16; k++) { const a = k / 16 * Math.PI * 4; const px = Math.cos(a) * (4 + k * 0.45), py = -5 + Math.sin(a) * (2 + k * 0.2); k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
    ctx.stroke(); ctx.fillStyle = '#66bb6a'; ctx.beginPath(); ctx.ellipse(9, -9, 3, 1.6, 0.5, 0, 7); ctx.fill();
  } else if (kind === 'poles') {
    ctx.fillStyle = '#8b6a3e'; ctx.fillRect(-20, -4, 40, 3.2);
  }
  ctx.restore();
}
function drawTeam() {
  const tm = S.team, logO = ob('log');
  const st = tm.mode === 'seq' && tm.seq ? tm.seq[tm.step] : null;
  const sp = st ? Math.min(1, tm.stepT / st.dur) : 0;
  const g = st && st.gather ? st : null;
  // materials: lying in the bush before pick-up, then piled up by the obstacle
  if (tm.seqOb) {
    const gy0 = memberY(tm.x);
    let pile = 0;
    if (g) {
      for (let i = 0; i < 4; i++) {
        const P = gatherPose(i, sp, g);
        if (!P.picked) drawItem(g.gather, tm.x + P.tx - camX, memberY(tm.x + P.tx) + P.tl, 1.25 * (1 + P.tl / 120));
        if (P.delivered) pile++;
      }
    } else if (tm.seq) {
      const done = tm.seq.slice(0, tm.step).find(x => x.gather);
      if (done) pile = Math.ceil(4 * (1 - (tm.seqOb.prog || 0)) - 0.001);
    }
    const kind = g ? g.gather : (tm.seq && (tm.seq.slice(0, tm.step).find(x => x.gather) || {}).gather);
    for (let k = 0; k < pile; k++) drawItem(kind, tm.x + 16 + (k % 2) * 6 - camX, gy0 + 6 - Math.floor(k / 1) * (kind === 'stones' ? 5 : 5), 1.3);
  }
  // training board
  if (st && st.train) {
    const bx = tm.x - 178 - camX, by = memberY(tm.x - 178);
    ctx.strokeStyle = '#6d4c2f'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(bx - 22, by); ctx.lineTo(bx - 10, by - 60); ctx.moveTo(bx + 22, by); ctx.lineTo(bx + 10, by - 60); ctx.stroke();
    ctx.fillStyle = '#fafafa'; ctx.strokeStyle = '#8d6e63'; ctx.lineWidth = 3; rr(bx - 42, by - 104, 84, 50, 4); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#263238'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(st.slow ? 'TRIAL &' : '🔨 HAMMER &', bx, by - 86); ctx.fillText(st.slow ? 'ERROR...' : 'CHISEL 101', bx, by - 72);
    ctx.textAlign = 'left';
  }
  // the break: a billy on a tiny campfire in the middle of the group
  if (st && st.rest) {
    const bx = tm.x - 54 - camX, by = memberY(tm.x - 54) + 24;
    ctx.fillStyle = '#ff7043'; ctx.beginPath(); ctx.moveTo(bx - 9, by); ctx.quadraticCurveTo(bx, by - 18 - Math.sin(S.t * 12) * 3, bx + 9, by); ctx.fill();
    ctx.fillStyle = '#ffca28'; ctx.beginPath(); ctx.moveTo(bx - 5, by); ctx.quadraticCurveTo(bx, by - 10 - Math.sin(S.t * 15) * 2, bx + 5, by); ctx.fill();
    ctx.strokeStyle = '#5d4037'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(bx - 12, by + 2); ctx.lineTo(bx + 12, by - 2); ctx.moveTo(bx - 12, by - 2); ctx.lineTo(bx + 12, by + 2); ctx.stroke();
    ctx.fillStyle = '#90a4ae'; ctx.fillRect(bx - 8, by - 30, 16, 14); ctx.fillStyle = '#b0bec5'; ctx.fillRect(bx - 8, by - 30, 16, 3);
    ctx.strokeStyle = '#607d8b'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(bx, by - 30, 8, Math.PI, 0); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 2;
    for (let k = 0; k < 2; k++) { const ph = (S.t * 0.8 + k * 0.5) % 1; ctx.globalAlpha = 1 - ph; ctx.beginPath(); ctx.moveTo(bx - 3 + k * 6, by - 34 - ph * 26); ctx.quadraticCurveTo(bx + 4 + k * 6, by - 40 - ph * 26, bx - 2 + k * 6, by - 46 - ph * 26); ctx.stroke(); }
    ctx.globalAlpha = 1;
  }
  for (let i = 3; i >= 0; i--) {
    let mx = tm.x - i * MEMBER_GAP + (i === 0 ? tm.m0 : 0);
    if (st && st.struggle && i === 3) mx -= 22 + Math.sin(S.t * 3) * 3; // Wattle falls behind
    let lane = laneOffset(mx), flip = false, carry = null, crouch = 0;
    let moving = tm.mode === 'walk' || (st && st.move != null);
    let mood = tm.mood;
    if (st && st.struggle && i === 3) mood = 'struggle';
    if (st && st.rest) { mood = 'rest'; flip = i < 2; mx += i < 2 ? 4 : -4; lane = 12; moving = false; }
    if (g) {
      const P = gatherPose(i, sp, g);
      mx = tm.x + P.x; lane = P.lane; flip = P.flip; crouch = P.crouch; moving = P.moving;
      if (P.carry) { carry = g.gather; mood = 'carry'; } else mood = g.lost ? 'confused' : 'walk';
    } else if (st && st.form === 'rock') {
      const k = Math.min(ease(Math.min(1, sp / 0.12)), ease(Math.min(1, (1 - sp) / 0.1)));
      mx = lerp(tm.x - i * MEMBER_GAP, tm.x + ROCK_FORM[i][0], k); lane = ROCK_FORM[i][1] * k; flip = ROCK_FORM[i][2] && k > 0.5;
    } else if (st && st.train) { flip = true; mood = 'learn'; }
    const gy = memberY(mx) + lane + (i === 0 ? tm.m0y : 0) + crouch;
    const ph = S.t * 9 + i * 1.7;
    let bob = moving ? Math.abs(Math.sin(ph)) * 2 : 0;
    if (tm.mood === 'happy') bob = Math.abs(Math.sin(S.t * 6 + i)) * 16;
    if (tm.cheer > 0) bob += Math.abs(Math.sin(S.t * 10 + i)) * 10 * tm.cheer;
    const shake = tm.mood === 'stuck' ? Math.sin(S.t * 30 + i) * 1.5 : 0;
    if (mx > logO.x - 6 && mx < logO.x + logO.w + 6) mood = 'sneak'; // crawling through the hollow log
    const s = KOALA_SCALE * (1 + lane / 120) * KOALA_SIZE[i];
    if (tm.tired && moving) bob *= 0.4;
    drawKoala(mx - camX + shake, gy - bob, s, TEAM_COLORS[i], moving ? Math.sin(ph) * (tm.tired ? 0.6 : 1) : 0, mood, i, flip, carry, { tired: tm.tired && mood !== 'happy', leaf: tm.leaf === i, lead: tm.lead === i });
    S.kpos[i] = { x: mx, y: gy, s };

    if (st && st.train && sp > (st.slow ? 0.5 : 0.25) + i * 0.12) { // the penny drops: lightbulbs
      ctx.font = '15px sans-serif'; ctx.fillText('💡', mx - camX - 24 * s / KOALA_SCALE - 8, gy - 60 * s / KOALA_SCALE);
    }
  }
  const p = agentPos('team');
  if (tm.mood === 'confused' || (g && g.lost)) { ctx.fillStyle = '#fff'; ctx.font = 'bold 18px sans-serif'; ctx.fillText('?', p.x - camX + 56 + Math.sin(S.t * 3) * 4, p.y + 4); }
  if (S.selected === 'team') ring(p.x - camX, p.y + 30, 74, '#5dd3ff');
  if (tm.upT > 0) badge(p.x - camX, p.y - 26, '🎓 UPSKILLED!', '#ffd34d', Math.min(1, tm.upT * 2));
  else if (st && st.train) badge(p.x - camX, p.y - 26, st.slow ? '📖 SELF-TAUGHT...' : '🎓 TRAINING', '#ffd34d', 1);
  else if (st && st.rest) badge(p.x - camX, p.y - 26, '☕ BREAK', '#b2ebf2', 1);
  else if (tm.fresh > 0) badge(p.x - camX, p.y - 26, '⚡ REFRESHED', '#b9f6ca', Math.min(1, tm.fresh * 2));
  else if (tm.supplied > 0) badge(p.x - camX, p.y - 26, '🪂 SUPPLIES ARRIVED', '#ffe082', Math.min(1, tm.supplied * 2));
  else if (S.idea.bulb) badge(p.x - camX, p.y - 26, '💡 BANJO HAS AN IDEA', '#b3e5fc', 0.8 + Math.sin(S.t * 5) * 0.2);
  else if (tm.tired && !S.finished) badge(p.x - camX, p.y - 26, '😓 EXHAUSTED', '#ffccbc', 1);
  else tag(p.x - camX, p.y - 26, 'TEAM', '#5dd3ff');
}
function badge(x, y, text, col, a) {
  ctx.save(); ctx.globalAlpha = a; ctx.font = 'bold 11px system-ui, sans-serif';
  const w = ctx.measureText(text).width + 16;
  ctx.fillStyle = col; ctx.strokeStyle = '#8a6d00'; ctx.lineWidth = 1.5; rr(x - w / 2, y - 10, w, 17, 8); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#3a2c00'; ctx.textAlign = 'center'; ctx.fillText(text, x, y + 3); ctx.textAlign = 'left'; ctx.restore();
}
// A cute koala, facing right, feet at (0,0). Hard hats on even koalas, bandanas on odd ones.
function drawKoala(x, y, s, col, swing, mood, i, flip = false, carry = null, ex = {}) {
  const t = S.t;
  ctx.save(); ctx.translate(x, y); ctx.scale(s * (flip ? -1 : 1), s * (mood === 'sneak' ? 0.86 : 1));
  if (mood === 'rest') ctx.translate(0, 6); // sitting down
  if (ex.tired) ctx.rotate(0.06);           // slumped forward
  if (ex.lead) { // a little leader pennant for the task they were handed
    ctx.strokeStyle = '#5d4037'; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(-9, -18); ctx.lineTo(-11, -74); ctx.stroke();
    ctx.fillStyle = '#ffd34d'; ctx.strokeStyle = '#b26a00'; ctx.lineWidth = 0.8;
    ctx.beginPath(); ctx.moveTo(-11, -74); ctx.lineTo(10, -68.5 + Math.sin(t * 6) * 1.5); ctx.lineTo(-11, -62); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#b26a00'; ctx.font = 'bold 8px sans-serif'; ctx.fillText('★', -8, -65.5);
  }
  // feet
  ctx.fillStyle = '#5f6368';
  ctx.beginPath(); ctx.ellipse(-5 + swing * 4, -2, 5, 3, 0, 0, 7); ctx.ellipse(6 - swing * 4, -2, 5, 3, 0, 0, 7); ctx.fill();
  // back arm
  ctx.strokeStyle = '#8a9198'; ctx.lineWidth = 5; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-4, -21); ctx.lineTo(-8 - swing * 3, -12); ctx.stroke();
  // body + belly
  ctx.fillStyle = '#9aa1a8'; ctx.beginPath(); ctx.ellipse(0, -15, 12, 14, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#e8e8e8'; ctx.beginPath(); ctx.ellipse(2.5, -13, 7, 9, 0, 0, 7); ctx.fill();
  // scarf / bandana neck
  if (i % 2 === 1) { ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(-8, -27); ctx.lineTo(10, -27); ctx.lineTo(2, -19); ctx.closePath(); ctx.fill(); }
  if (ex.leaf) { // "Koala of the week": a gum leaf pinned on the chest
    ctx.fillStyle = '#7cb342'; ctx.beginPath(); ctx.ellipse(4, -16, 2.6, 6, 0.6, 0, 7); ctx.fill();
    ctx.strokeStyle = '#33691e'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(0.5, -11); ctx.lineTo(7.5, -21); ctx.stroke();
  }
  // ears (big and fluffy)
  for (const ex of [-10, 12]) {
    ctx.fillStyle = '#a7aeb5'; ctx.beginPath(); ctx.arc(ex, -44, 8, 0, 7); ctx.fill();
    ctx.fillStyle = '#f6f6f6';
    for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2 + 0.3; ctx.beginPath(); ctx.arc(ex + Math.cos(a) * 6.8, -44 + Math.sin(a) * 6.8, 2.6, 0, 7); ctx.fill(); }
    ctx.fillStyle = '#ecc9cf'; ctx.beginPath(); ctx.arc(ex, -44, 4, 0, 7); ctx.fill();
  }
  // head
  ctx.fillStyle = '#a7aeb5'; ctx.beginPath(); ctx.arc(1, -35, 11.5, 0, 7); ctx.fill();
  ctx.fillStyle = '#c2c8cd'; ctx.beginPath(); ctx.ellipse(3, -31, 7, 5, 0, 0, 7); ctx.fill();
  // headwear
  if (i % 2 === 0) { // hard hat
    ctx.fillStyle = col; ctx.beginPath(); ctx.arc(1, -44, 8.5, Math.PI, 0); ctx.fill();
    ctx.fillRect(-9, -45, 20, 3);
    ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.fillRect(-1, -52, 3, 7);
  } else { // bandana tied round the head
    ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(1, -43, 10.5, 4, 0, Math.PI, 0); ctx.fill(); ctx.fillRect(-9.5, -44, 21, 3.5);
    ctx.beginPath(); ctx.moveTo(-10, -42); ctx.lineTo(-17, -46 + Math.sin(t * 8 + i) * 2); ctx.lineTo(-15, -39); ctx.fill();
  }
  // eyes
  ctx.fillStyle = '#1d1d1d';
  if (mood === 'happy' || mood === 'rest') { ctx.strokeStyle = '#1d1d1d'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(-1, -36, 2, Math.PI, 0); ctx.arc(8, -36, 2, Math.PI, 0); ctx.stroke(); }
  else if (ex.tired || mood === 'struggle') { ctx.strokeStyle = '#1d1d1d'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-3.5, -36); ctx.lineTo(1.5, -36.5); ctx.moveTo(5.5, -36.5); ctx.lineTo(10.5, -36); ctx.stroke(); }
  else { ctx.beginPath(); ctx.arc(-1, -37, 1.7, 0, 7); ctx.arc(8, -37, 1.7, 0, 7); ctx.fill(); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-0.5, -37.6, 0.6, 0, 7); ctx.arc(8.5, -37.6, 0.6, 0, 7); ctx.fill(); }
  // big black nose
  ctx.fillStyle = '#262626'; ctx.beginPath(); ctx.ellipse(4, -31, 3.8, 4.8, 0, 0, 7); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.ellipse(3, -33, 1, 1.5, 0, 0, 7); ctx.fill();
  // mouth
  if (mood === 'stuck' || mood === 'confused' || mood === 'struggle' || ex.tired) { ctx.fillStyle = '#5a2a2a'; ctx.beginPath(); ctx.ellipse(4, -25, 2, 1.6, 0, 0, 7); ctx.fill(); }
  if (ex.tired || mood === 'struggle') { // sweat drops
    ctx.fillStyle = '#81d4fa';
    for (let k = 0; k < 2; k++) { const ph = (t * 1.3 + k * 0.5 + i * 0.3) % 1; ctx.globalAlpha = 1 - ph; ctx.beginPath(); ctx.ellipse(-12 - k * 4, -40 + ph * 14 + k * 6, 1.6, 2.6, 0, 0, 7); ctx.fill(); }
    ctx.globalAlpha = 1;
  }
  // front arm + tool (a small pruning saw: red garden-tool handle, toothed blade)
  let a;
  if (mood === 'hack') a = -1.4 + (Math.sin(t * 16 + i * 1.1) * 0.5 + 0.5) * 2.3;
  else if (mood === 'work') a = -1.0 + (Math.sin(t * 11 + i) * 0.5 + 0.5) * 1.6;
  else if (mood === 'chisel') { const ph = (t * 1.5 + i * 0.27) % 1; a = ph < 0.75 ? lerp(0.15, -1.9, ease(ph / 0.75)) : lerp(-1.9, 0.3, (ph - 0.75) / 0.25); }
  else if (mood === 'happy') a = -1.9 + Math.sin(t * 8 + i) * 0.3;
  else if (mood === 'stuck') a = Math.sin(t * 18 + i) * 1.1 - 0.4;
  else if (mood === 'struggle') a = -0.5 + Math.sin(t * 24) * 0.12; // saw jammed, arm trembling
  else if (mood === 'rest') a = i % 2 ? -1.3 + Math.sin(t * 2 + i) * 0.25 : -1.7 + Math.max(0, Math.sin(t * 1.6 + i)) * 0.6; // munching / drinking
  else if (mood === 'sneak') a = -2.2;
  else if (mood === 'carry') a = -0.2;
  else if (mood === 'learn') a = 0.5 + Math.sin(t * 3 + i) * 0.15;
  else a = 0.9 + swing * 0.3;
  const sx = 5, sy = -22, len = mood === 'sneak' ? 7 : 9;
  const hx = sx + Math.cos(a) * len, hy = sy + Math.sin(a) * len;
  if (mood === 'carry' && carry) drawItem(carry, 13, -15, 1.0);
  if (mood === 'rest') { // water bottle (hard hats) or a eucalyptus leaf snack (bandanas)
    ctx.save(); ctx.translate(hx, hy);
    if (i % 2) { ctx.fillStyle = '#7cb342'; ctx.beginPath(); ctx.ellipse(2, -3, 3, 7, 0.5, 0, 7); ctx.fill(); }
    else { ctx.rotate(a + 1.2); ctx.fillStyle = '#4fc3f7'; rr(-2.5, -9, 5, 12, 2); ctx.fill(); ctx.fillStyle = '#0277bd'; ctx.fillRect(-2, -11, 4, 2.5); }
    ctx.restore();
  }
  if (mood === 'chisel') {
    // chisel held against the rock, hammer swinging down onto it
    ctx.fillStyle = '#90a4ae'; ctx.fillRect(10, -19, 9, 2.4); ctx.fillStyle = '#6d4c2f'; ctx.fillRect(7, -19.4, 4, 3.2);
    ctx.save(); ctx.translate(hx, hy); ctx.rotate(a + 0.25);
    ctx.fillStyle = '#8d6e63'; ctx.fillRect(-1, -1.5, 14, 3);
    ctx.fillStyle = '#455a64'; ctx.fillRect(12, -6, 6.5, 12); ctx.fillStyle = '#78909c'; ctx.fillRect(12, -6, 6.5, 2.5);
    ctx.restore();
  } else if (mood === 'hack' || mood === 'work' || mood === '' || mood === 'walk' || mood === 'struggle') {
    const ba = mood === 'struggle' ? a + 0.9 : mood === 'hack' || mood === 'work' ? a + 0.25 : 1.35;
    ctx.save(); ctx.translate(hx, hy); ctx.rotate(ba);
    ctx.fillStyle = '#d84315'; rr(-4, -2.6, 7, 5.2, 2); ctx.fill();
    ctx.fillStyle = '#dfe6ea'; ctx.strokeStyle = '#607d8b'; ctx.lineWidth = 0.9;
    ctx.beginPath(); ctx.moveTo(3, -2.4); ctx.lineTo(17, -1.2);
    for (let k = 0; k <= 6; k++) ctx.lineTo(17 - k * 2.33, 1.4 + (k % 2 ? 1.5 : 0));
    ctx.lineTo(3, 2.4); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
  }
  ctx.strokeStyle = '#9aa1a8'; ctx.lineWidth = 5; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(hx, hy); ctx.stroke();
  ctx.fillStyle = '#7d848b'; ctx.beginPath(); ctx.arc(hx, hy, 2.6, 0, 7); ctx.fill();
  ctx.lineCap = 'butt';
  ctx.restore();
}

function drawKoalaLabels() {
  const shown = new Set();
  for (const b of S.kb) {
    const P = S.kpos[b.i]; if (!P) continue;
    shown.add(b.i);
    badge(P.x - camX, P.y + 20 + (b.i % 2) * 18, b.text, b.col, Math.min(1, b.t * 2, (b.dur - b.t) * 4));
  }
  if (S.hover >= 0 && !shown.has(S.hover) && S.kpos[S.hover]) {
    const P = S.kpos[S.hover], K = KOALAS[S.hover];
    badge(P.x - camX, P.y + 22, `🐨 ${K.name} (${K.desc})`, ['#ffd0a6', '#bcd9ff', '#fff1a8', '#e2c6f5'][S.hover], 1);
  }
}
// The supply drop: a crate on a parachute floats down through a gap in the canopy.
function drawDrop(phase) {
  const D = S.drop; if (!D) return;
  const x = D.x - camX; if (x < -100 || x > viewW + 100) return;
  const a = 1 - Math.min(1, D.fade || 0);
  ctx.save(); ctx.globalAlpha = a;
  if (phase === 'gap' && !D.landed) { // light pours through the canopy gap
    const g = ctx.createLinearGradient(0, CANOPY_TOP, 0, GROUND);
    g.addColorStop(0, 'rgba(255,250,210,0.5)'); g.addColorStop(1, 'rgba(255,250,210,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x - 34, CANOPY_TOP + 40); ctx.lineTo(x + 34, CANOPY_TOP + 40); ctx.lineTo(x + 70, GROUND); ctx.lineTo(x - 70, GROUND); ctx.fill();
    ctx.restore(); return;
  }
  if (phase === 'gap') { ctx.restore(); return; }
  const q = Math.min(1, D.t / 3.0), y = lerp(CANOPY_TOP - 70, GROUND - 2, q), sway = D.landed ? 0 : Math.sin(D.t * 3) * 6;
  if (!D.landed) {
    ctx.fillStyle = 'rgba(158,224,255,0.55)'; ctx.beginPath(); ctx.ellipse(x, CANOPY_TOP + 40, 46, 22, 0, 0, 7); ctx.fill(); // the gap
    ctx.strokeStyle = '#eceff1'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x + sway - 26, y - 62); ctx.lineTo(x - 12, y - 24); ctx.moveTo(x + sway + 26, y - 62); ctx.lineTo(x + 12, y - 24); ctx.moveTo(x + sway, y - 70); ctx.lineTo(x, y - 24); ctx.stroke();
    ctx.fillStyle = '#ef5350'; ctx.beginPath(); ctx.arc(x + sway, y - 60, 28, Math.PI, 0); ctx.fill();
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(x + sway - 9, y - 60); ctx.arc(x + sway, y - 60, 28, Math.PI * 1.35, Math.PI * 1.65); ctx.closePath(); ctx.fill();
  }
  ctx.fillStyle = '#a1774a'; ctx.strokeStyle = '#5d4037'; ctx.lineWidth = 2; ctx.fillRect(x - 16, y - 24, 32, 24); ctx.strokeRect(x - 16, y - 24, 32, 24);
  ctx.beginPath(); ctx.moveTo(x - 16, y - 24); ctx.lineTo(x + 16, y); ctx.moveTo(x + 16, y - 24); ctx.lineTo(x - 16, y); ctx.stroke();
  if (D.landed) { // opened: a saw and a hard hat
    ctx.fillStyle = '#ffca28'; ctx.beginPath(); ctx.arc(x - 6, y - 26, 6, Math.PI, 0); ctx.fill(); ctx.fillRect(x - 13, y - 27, 14, 2);
    ctx.fillStyle = '#dfe6ea'; ctx.fillRect(x + 2, y - 34, 3, 10); ctx.fillStyle = '#d84315'; ctx.fillRect(x + 1.5, y - 38, 4, 5);
    tag(x, y + 16, 'SAWS + SAFETY GEAR', '#ffe082');
  }
  ctx.restore();
}
// A gum leaf flies from the owl to Matilda.
function drawLeafFly() {
  const L = S.leafFly, P = S.kpos[2]; if (!L || !P) return;
  const q = ease(Math.min(1, L.t / 0.9)), m = agentPos('manager');
  const x = lerp(m.x, P.x, q) - camX, y = lerp(m.y + 10, P.y - 30 * P.s / KOALA_SCALE, q) - Math.sin(Math.PI * q) * 40;
  ctx.save(); ctx.translate(x, y); ctx.rotate(S.t * 6);
  ctx.fillStyle = '#7cb342'; ctx.beginPath(); ctx.ellipse(0, 0, 4, 9, 0, 0, 7); ctx.fill(); ctx.restore();
}

function drawParticles() {
  for (const p of S.particles) {
    ctx.save(); ctx.translate(p.x - camX, p.y); ctx.rotate(p.r);
    ctx.fillStyle = p.c; ctx.globalAlpha = Math.min(1, p.life);
    if (p.kind === 'leaf') { ctx.beginPath(); ctx.ellipse(0, 0, 4.5, 2, 0, 0, 7); ctx.fill(); }
    else ctx.fillRect(-3, -2, 6, 4);
    ctx.restore();
  }
}

// ---------- v3 drawing: surprises, meetings ----------
function drawSurprises(late) {
  for (const sp of S.surprises) {
    if ((sp.type === 'treefall' || sp.type === 'snake') !== !!late) continue; // the fallen tree lies in front of the bush row
    const x = sp.x - camX; if (x > viewW + 220 || x + sp.w < -220) continue;
    const gy = groundBase(sp.x + sp.w / 2);
    if (sp.type === 'sinkhole' && sp.rev > 0) {
      const e = ease(sp.rev), cx = x + sp.w / 2;
      ctx.fillStyle = '#8a6a44'; ctx.beginPath(); ctx.ellipse(cx, gy + 5, sp.w / 2 * e + 6, 13 * e + 3, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#140c05'; ctx.beginPath(); ctx.ellipse(cx, gy + 6, sp.w / 2 * e, 11 * e, 0, 0, 7); ctx.fill();
      if (sp.rev < 1 && Math.random() < 0.5) S.particles.push({ kind: 'confetti', x: sp.x + Math.random() * sp.w, y: gy, vx: (Math.random() - 0.5) * 40, vy: -30, r: 0, vr: 3, life: 0.6, c: '#7a5a3a' });
      const n = Math.floor(sp.prog * 6 + 0.0001);
      ctx.fillStyle = '#9a6a3a'; ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = 1;
      for (let k = 0; k < n; k++) { const px = x - 8 + k * (sp.w + 16) / 6; ctx.fillRect(px, gy - 5, (sp.w + 16) / 6 - 2, 9); ctx.strokeRect(px, gy - 5, (sp.w + 16) / 6 - 2, 9); }
    } else if (sp.type === 'treefall') {
      const bx = x + sp.w + 40, Lt = 175, e = ease(sp.rev);
      const lift = sp.prog * 24, fade = 1 - sp.prog * 0.55, shrink = 1 - sp.prog * 0.25;
      ctx.save(); ctx.globalAlpha = fade; ctx.translate(bx, gy - lift - 26 * e); ctx.scale(shrink, shrink); ctx.rotate(-Math.PI / 2 * e);
      ctx.fillStyle = '#8a5a34'; ctx.strokeStyle = '#3e2410'; ctx.lineWidth = 2.5; ctx.fillRect(-14, -Lt, 28, Lt); ctx.strokeRect(-14, -Lt, 28, Lt);
      ctx.fillStyle = '#e3c08a'; ctx.beginPath(); ctx.ellipse(0, 0, 14, 5, 0, 0, 7); ctx.fill(); ctx.stroke(); // fresh broken base
      ctx.strokeStyle = 'rgba(40,25,10,0.5)'; ctx.lineWidth = 2;
      for (let k = 1; k < 6; k++) { ctx.beginPath(); ctx.moveTo(-8, -k * 28); ctx.lineTo(8, -k * 28 - 6); ctx.stroke(); }
      if (sp.prog > 0) { ctx.strokeStyle = '#f2d9a8'; ctx.lineWidth = 3; for (const k of [0.33, 0.66]) { ctx.beginPath(); ctx.moveTo(-11, -Lt * k); ctx.lineTo(11, -Lt * k); ctx.stroke(); } }
      ctx.fillStyle = '#3f8f3a';
      for (const [cx2, cy2, r2] of [[0, -Lt - 8, 34], [-22, -Lt + 14, 24], [22, -Lt + 12, 24]]) { ctx.beginPath(); ctx.arc(cx2, cy2, r2, 0, 7); ctx.fill(); }
      ctx.restore();
      if (sp.rev > 0.97 && sp.rev < 1 && !sp.crashed) { sp.crashed = true; for (let i = 0; i < 16; i++) leaf(sp.x + Math.random() * 40, gy - 20); }
    } else if (sp.type === 'snake' && sp.rev > 0) {
      const leaving = sp.prog > 0, dir = leaving ? 1 : -1;
      const hx = leaving ? lerp(x + sp.w * 0.35, x + sp.w + 160, ease(sp.prog)) : lerp(x + sp.w + 90, x + sp.w * 0.35, ease(sp.rev));
      ctx.save(); ctx.globalAlpha = leaving ? 1 - sp.prog * 0.8 : 1;
      ctx.translate(hx, gy); ctx.scale(1.7, 1.7); ctx.translate(-hx, -gy - 3); // big enough to read, in front of the bush row
      const pts = []; for (let k = 0; k < 24; k++) pts.push([hx - dir * k * 5, gy - 4 + Math.sin(k * 0.55 - S.t * 7 * (sp.done ? 0 : 1)) * 4]);
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = '#7b5a2e'; ctx.lineWidth = 8; ctx.beginPath(); pts.forEach(([px, py], k) => k ? ctx.lineTo(px, py) : ctx.moveTo(px, py)); ctx.stroke();
      ctx.strokeStyle = '#c9a06a'; ctx.lineWidth = 2.5; ctx.beginPath(); pts.forEach(([px, py], k) => k ? ctx.lineTo(px, py + 1.5) : ctx.moveTo(px, py + 1.5)); ctx.stroke();
      ctx.fillStyle = '#6b4a22'; ctx.beginPath(); ctx.ellipse(hx + dir * 4, gy - 5, 8, 5.5, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#ffeb3b'; ctx.beginPath(); ctx.arc(hx + dir * 7, gy - 7, 1.6, 0, 7); ctx.fill();
      if (Math.sin(S.t * 9) > 0.2) { ctx.strokeStyle = '#e53935'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(hx + dir * 12, gy - 5); ctx.lineTo(hx + dir * 19, gy - 5); ctx.lineTo(hx + dir * 22, gy - 8); ctx.moveTo(hx + dir * 19, gy - 5); ctx.lineTo(hx + dir * 22, gy - 2); ctx.stroke(); }
      ctx.restore(); ctx.lineCap = 'butt'; ctx.lineJoin = 'miter';
    }
  }
}
function drawSurpriseMarkers() {
  for (const sp of S.surprises) {
    if (sp.rev <= 0 || sp.done) continue;
    const cx = sp.x + sp.w / 2 - camX; if (cx < -40 || cx > viewW + 40) continue;
    const cy = groundBase(sp.x + sp.w / 2) - 190, k = 1 + Math.sin(S.t * 6) * 0.08;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(k, k);
    ctx.fillStyle = 'rgba(255,87,34,0.25)'; ctx.beginPath(); ctx.arc(0, 0, 24, 0, 7); ctx.fill();
    ctx.fillStyle = '#ff5722'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(0, 0, 16, 0, 7); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 20px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('?', 0, 7);
    ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillStyle = '#ffccbc'; ctx.fillText('UNPLANNED', 0, -27); ctx.textAlign = 'left';
    ctx.restore();
  }
}
function drawEagleShape(x, y, s, body, head, flapSpeed, phase) {
  const flap = Math.sin(S.t * flapSpeed + phase) * 14;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  ctx.fillStyle = body;
  ctx.beginPath(); ctx.moveTo(-4, 0); ctx.quadraticCurveTo(-26, -10 - flap, -52, -4 - flap * 1.4); ctx.quadraticCurveTo(-30, 4, -4, 6); ctx.fill();
  ctx.beginPath(); ctx.moveTo(4, 0); ctx.quadraticCurveTo(26, -10 - flap, 52, -4 - flap * 1.4); ctx.quadraticCurveTo(30, 4, 4, 6); ctx.fill();
  ctx.beginPath(); ctx.ellipse(0, 2, 10, 18, 0, 0, 7); ctx.fill();
  ctx.fillStyle = head; ctx.beginPath(); ctx.arc(0, -14, 8, 0, 7); ctx.fill();
  ctx.fillStyle = '#f2b233'; ctx.beginPath(); ctx.moveTo(-3, -11); ctx.lineTo(0, -4); ctx.lineTo(3, -11); ctx.fill();
  ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(-3, -16, 1.4, 0, 7); ctx.arc(3, -16, 1.4, 0, 7); ctx.fill();
  ctx.restore();
}
function drawMeeting() {
  const M = S.leader.meeting; if (!M) return;
  const d = M.def;
  ctx.font = '600 12px system-ui, sans-serif';
  d.visitors.forEach((v, i) => {
    const p = visitorPos(M, i), x = p.x - camX, y = p.y;
    drawEagleShape(x, y, v.size, v.body, v.head, 6, i * 1.3);
    tag(x, y + 30 * v.size + 6, v.label, v.head);
    const c = M.cards[i];
    if (!c.shown && M.phase !== 'decide' && M.phase !== 'leave') return;
    const text = (c.state === 'yes' ? '✅ ' : c.state === 'parked' ? '⏸ Parked: ' : '') + v.ask;
    const w = ctx.measureText(text).width + 18, h = 22;
    let cx = clamp(x - w / 2, 4, viewW - w - 4), cy = Math.max(4, y - 30 * v.size - 30);
    if (settings.view !== 'team' && settings.view !== 'manager' && cx < 356 && cy < 50) cy = 50; // keep clear of the minimap
    let a = 1;
    if (M.phase === 'leave') { const q = Math.min(1, M.t / MEETING_PHASES.leave); a = 1 - q; if (c.state === 'yes') { const L = S.leader; cx = lerp(cx, L.x - camX - w / 2, q); cy = lerp(cy, L.y, q); } }
    ctx.globalAlpha = a;
    ctx.fillStyle = c.state === 'yes' ? '#e8f5e9' : c.state === 'parked' ? '#e0e0e0' : '#fffde7';
    ctx.strokeStyle = c.state === 'yes' ? '#2e7d32' : c.state === 'parked' ? '#9e9e9e' : '#f9a825';
    ctx.lineWidth = 2; rr(cx, cy, w, h, 6); ctx.fill(); ctx.stroke();
    ctx.fillStyle = c.state === 'parked' ? '#777' : '#222'; ctx.fillText(text, cx + 9, cy + 15);
    if (c.state === 'parked') { ctx.strokeStyle = '#888'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(cx + 8, cy + 11); ctx.lineTo(cx + w - 8, cy + 11); ctx.stroke(); }
    ctx.globalAlpha = 1;
  });
}

function drawMiniMap() {
  if (settings.view === 'team' || settings.view === 'manager') return;
  const w = 340, h = 34, x = 12, y = 12, k = (w - 20) / WORLD_W;
  ctx.fillStyle = 'rgba(255,255,255,0.75)'; rr(x, y, w, h, 8); ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1; ctx.stroke();
  ctx.fillStyle = '#2e7d32'; ctx.fillRect(x + 10, y + 20, w - 20, 4);
  const lx0 = x + 10 + LANTANA.x0 * k, lx1 = x + 10 + LANTANA.x1 * k;
  ctx.fillStyle = S.idea.adopted ? 'rgba(120,80,40,0.35)' : '#8d6e3f'; ctx.fillRect(lx0, y + 19, lx1 - lx0, 6); // lantana on the planned route
  if (S.idea.adopted) { // the new route, via the creek
    ctx.save(); ctx.strokeStyle = '#1e88e5'; ctx.lineWidth = 2.5; ctx.setLineDash([3, 2]);
    ctx.beginPath(); ctx.moveTo(x + 10 + CREEK.x0 * k, y + 22); ctx.quadraticCurveTo((lx0 + lx1) / 2, y + 33, x + 10 + CREEK.x1 * k, y + 22); ctx.stroke(); ctx.restore();
  }
  ctx.font = '11px sans-serif';
  ctx.fillText('🏁', x + 10 + START_X * k - 6, y + 17);
  for (const o of S.obstacles) { ctx.globalAlpha = o.done ? 0.35 : 1; ctx.fillText(o.icon, x + 10 + o.x * k - 6, y + 17); ctx.globalAlpha = 1; }
  for (const o of S.surprises) { if (o.rev <= 0) continue; ctx.globalAlpha = o.done ? 0.35 : 1; ctx.fillText('❓', x + 10 + o.x * k - 6, y + 17); ctx.globalAlpha = 1; }
  ctx.fillText('🔺', x + 10 + GOAL_X * k - 6, y + 17);
  const dot = (wx, c) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x + 10 + wx * k, y + 22, 3.5, 0, 7); ctx.fill(); };
  dot(S.team.x, '#1f8fd0'); dot(S.mgr.x, '#9b59d0'); dot(S.leader.x, '#d4a000');
  ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.strokeRect(x + 10 + camX * k, y + 4, viewW * k, h - 8);
}

function render() {
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  drawSky();
  drawUnderstory();
  drawTrunks();
  drawPyramid();
  drawHangingVines();
  drawRiver(false);
  drawGround();
  drawBog(false);
  drawStartCamp();
  drawBoulder();
  drawCliff();
  drawWall();
  drawVineThicket();
  drawBees(false);
  drawSurprises();
  drawCreek();
  drawLantana();
  drawTeam();
  drawSurpriseMarkers();
  drawBees(true);
  drawRiver(true);
  drawBog(true);
  drawLog();
  drawBushes();
  drawPathBushes();
  drawRubble();
  drawSurprises(true);
  drawKoalaLabels();
  drawDrop('gap');
  drawManager();
  drawMgrMeeting();
  drawCanopy();
  drawDrop('crate');
  drawLeafFly();
  drawMeeting();
  drawLeader();
  drawFog();
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  drawBeam();
  drawPulses();
  drawParticles();
  drawBubbles();
  drawMiniMap();
  drawViewBanner();
}

function onClick(ev) {
  const rect = canvas.getBoundingClientRect();
  const sx = (ev.clientX - rect.left) * (canvas.width / rect.width) / scale;
  const sy = (ev.clientY - rect.top) * (canvas.height / rect.height) / scale;
  const wx = sx + camX;
  const near = (p, r) => Math.hypot(p.x - wx, p.y - sy) < r;
  let hit = null;
  if (near(agentPos('leader'), 48)) hit = 'leader';
  else if (near(agentPos('manager'), 44)) hit = 'manager';
  else {
    const tx = S.team.x;
    if (wx > tx - MEMBER_GAP * 3 - 22 && wx < tx + 22 && sy > memberY(tx) - 95 && sy < memberY(tx) + 50) hit = 'team';
    else {
      const by = groundBase(GOAL_X), half = PYR_HALF * (sy - PYR_APEX) / (by - PYR_APEX);
      if (sy > PYR_APEX && sy < by && Math.abs(wx - GOAL_X) < half) hit = 'goal';
    }
  }
  S.selected = hit;
  call('OnAgentClicked', hit || '');
}
function onMove(ev) {
  const rect = canvas.getBoundingClientRect();
  const sx = (ev.clientX - rect.left) * (canvas.width / rect.width) / scale, sy = (ev.clientY - rect.top) * (canvas.height / rect.height) / scale;
  let h = -1;
  S.kpos.forEach((P, i) => { if (P && Math.abs(P.x - camX - sx) < 16 * P.s && sy < P.y + 4 && sy > P.y - 56 * P.s) h = i; });
  if (h !== S.hover) { S.hover = h; canvas.title = h >= 0 ? `${KOALAS[h].name} (${KOALAS[h].desc})` : ''; canvas.style.cursor = h >= 0 ? 'pointer' : ''; }
}

// ---------- public API (called from Blazor) ----------
export function init(canvasEl, dotnetRef) {
  canvas = canvasEl; ctx = canvas.getContext('2d'); dotnet = dotnetRef;
  fog = document.createElement('canvas'); fctx = fog.getContext('2d');
  deco = buildDeco();
  reset();
  resize();
  ro = new ResizeObserver(resize); ro.observe(canvas);
  canvas.addEventListener('click', onClick);
  canvas.addEventListener('mousemove', onMove);
  window.addEventListener('keydown', onKey);
  lastT = 0; raf = requestAnimationFrame(frame);
  window.aboveTheCanopy = { settings, get state() { return S; }, get cam() { return { camX, scale, viewW }; }, fastForward, restart, runToEnd };
}
export function setPlaying(p) { settings.playing = !!p; }
export function restart() { reset(); }
export function setSpeed(v) { settings.speed = clamp(+v || 1, 0.1, 5); }
export function setView(v) { settings.view = v; }
export function setComms(on) { settings.comms = !!on; }
export function select(role) { S.selected = role || null; }
export function fastForward(seconds) { const step = 1 / 30; for (let t = 0; t < seconds; t += step) { update(step); updateCamera(step); } render(); }
// Simulates a full run (used for testing pacing); returns the sim-time when the team finished.
export function runToEnd(maxSeconds = 600) { const step = 1 / 30; while (!S.finished && S.t < maxSeconds) { update(step); updateCamera(step); } render(); return S.t; }
export function dispose() {
  cancelAnimationFrame(raf);
  if (ro) ro.disconnect();
  if (canvas) { canvas.removeEventListener('click', onClick); canvas.removeEventListener('mousemove', onMove); }
  window.removeEventListener('keydown', onKey);
  dotnet = null;
}
